<?php
function showPopup($message)
{
    if (isset($message)) {

        $msg = $message;

    echo "
    <div class='popup-box'>
         $msg
    </div>
    ";

    }
}

function popup($message)
{
    showPopup($message);
}

?>