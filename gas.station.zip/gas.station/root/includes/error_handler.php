<?php
error_reporting(E_ALL);

// Don’t show errors to users (safe for production)
ini_set('display_errors', 0);

// Log all errors to a file
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../../root/includes/error_log.txt'); 
require_once "C:\Projects\gas.station\db\db_person.php";
?>
