<?php
// Detect current page (for active highlight)
require_once "C:\Projects\gas.station\db\db_acl.php";
require_once "C:\Projects\gas.station\db\db_person_role.php";

$currentPage = basename($_SERVER['PHP_SELF']);
$per_id = base64_decode($_SESSION['per_id']);

$person_role = new db_person_role();

$acl = new db_acl();
$acl_id = $person_role->getPersonRoleById($per_id)->prl_ref_acl;
$acl_role = $acl->getAclRole($acl_id)->acl_role;

$menuItems = [
    ['label' => 'System', 'icon' => '⚙️', 'link' => "/?view=app&id={$_SESSION['per_id']}", 'roles' => ['Dev', 'Manager','Owner']],
    ['label' => 'Dashboard', 'icon' => '📊', 'link' => "/?view=dashboard&id={$_SESSION['per_id']}", 'roles' => ['Dev', 'Manager','Cashier','Owner', 'Attendant', 'Carwasher']],
    ['label' => 'Inventory', 'icon' => '📦', 'link' => "/?view=inventory&id={$_SESSION['per_id']}",'roles' => ['Dev','Manager','Owner', 'Attendant'] ],
    ['label' => 'Shop',      'icon' => '🛒', 'link' => "/?view=shop&id={$_SESSION['per_id']}", 'roles' => ['Dev','Manager','Owner', 'Cashier']],
    ['label' => 'Bakery',    'icon' => '🍞', 'link' => "/?view=bakery&id={$_SESSION['per_id']}", 'roles' => ['Dev','Manager','Owner', 'Cashier']],
    ['label' => 'Carwash',   'icon' => '🚗', 'link' => "/?view=carwash&id={$_SESSION['per_id']}", 'roles' => ['Dev', 'Manager','Owner', 'Carwasher']],
    // ['label' => 'Profile',   'icon' => '👤', 'link' => "/?view=profile&id={$_SESSION['per_id']}",'roles' => ['Dev', 'Manager','Cashier','Owner', 'Attendant', 'Carwasher']],
    ['label' => 'Log out',   'icon' => '⏻', 'link' => "/?view=login",'roles' => ['Dev', 'Manager','Cashier','Owner', 'Attendant', 'Carwasher']],
];
?>

<aside id="sidebar" class="sidebar">
    <div class="sidebar-header">
    <button class="toggle-btn" id="toggle-btn">☰</button>
    </div>

    <ul class="sidebar-menu">
        
        <?php foreach ($menuItems as $item): 
            if(!in_array($acl_role, $item['roles'])) continue;

            $active = (strpos($_SERVER['QUERY_STRING'], "view=" . basename($item['link'])) !== false) ? 'active' : '';

        ?>
            <li class="menu-item <?= $active ?>">
                <a href="<?= $item['link'] ?>">
                    <span class="icon"><?= $item['icon'] ?></span>
                    <span class="text"><?= $item['label'] ?></span>
                </a>
            </li>
        <?php endforeach;
?>
    </ul>
</aside>

<script>
    const toggleBtn = document.getElementById('toggle-btn');
    const sidebar = document.getElementById('sidebar');

    toggleBtn.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
        document.body.classList.toggle('sidebar-collapsed');
    });
</script>