
<?php session_start();
include_once "../db/connection.php";
require_once('C:\Projects\gas.station\root\includes\error_handler.php');

$view = $_GET["view"];

if(isset($_GET["id"])) $_SESSION["per_id"] = $_GET["id"];
if(empty($view))
{
    header("Location: http://gas.station:8081/?view=login");
}

switch($view){

case "login":
    include_once("../ui/login/login_view.php");
    break;

case "register";
    include_once("../ui/register/register_view.php");
    break;

case "dashboard":
    include_once ("../ui/dashboard/dashboard_view.php");
    break;

case "notification_log_view":
    include_once("../ui/dashboard/components/notification_log_view.php");
    break;

case "inventory":
    include_once("../ui/inventory/inventory_view.php");
    break;

case "shop":
    include_once("../ui/shop/shop_view.php");
    break;

case "bakery":
    include_once("../ui/bakery/bakery_view.php");
    break;

case "carwash":
    include_once("../ui/carwash/carwash_view.php");
    break;

case "profile":
    include_once("../ui/profile/profile_view.php");
    break;

case "xregister":
    include_once("../ui/register/functions/xregister.php");
    break;
    
case "xlogin":
    include_once("../ui/login/functions/xlogin.php");
    break;

case "total_revenue_view":
    include_once('../ui/dashboard/stats/total_revenue_view.php');
    break;

case "total_fuel_sold_view":
    include_once('../ui/dashboard/stats/total_fuel_sold_view.php');
    break;

case "active_pumps_view":
    include_once('../ui/dashboard/stats/active_pumps_view.php');
    break;

case "total_shop_sales_view":
    include_once('../ui/dashboard/stats/total_shop_sales_view.php');
    break;

case "total_bakery_sales_view":
    include_once('../ui/dashboard/stats/total_bakery_sales_view.php');
    break;
    
case "total_carwash_sales_view":
    include_once('../ui/dashboard/stats/total_carwash_sales_view.php');
    break;

case "carwash_type_view";
    include_once('../ui/dashboard/stats/carwash_type_view.php');
    break;

case "tank_view";
    include_once('../ui/dashboard/stats/tank_view.php');
    break;

case "product_view";
    include_once('../ui/dashboard/stats/product_view.php');
    break;

case "edit_profile";
    include_once('../ui/profile/edit_profile.php');
    break;

case "xedit_profile";
    include_once('../ui/profile/functions/xedit_profile.php');
    break;

case "sidebar";
    include_once('../root/includes/sidebar.php');
    break;

case "app";
    include_once('../app/dashboard/dashboard_view.php');
    break;

case "backend_person";
    include_once('../app/person/person.php');
    break;

case "person_add";
    include_once('../app/person/person_add.php');
    break;

case "xadd_person";
    include_once('../app/person/function/xadd_person.php');
    break;

case "person_edit";
    include_once('../app/person/person_edit.php');
    break;

case "xedit_person";
    include_once('../app/person/function/xedit_person.php');
    break;

case "person_delete";
    include_once('../app/person/function/xdelete_person.php');
    break;

case "person_view";
    include_once('../app/person/person_view.php');
    break;

case "backend_shop";
    include_once('../app/shop/shop.php');
    break;

case "backend_inventory";
    include_once('../app/inventory/inventory.php');
    break;

case "inventory_add";
    include_once('../app/inventory/inventory_add.php');
    break;

case "xadd_inventory";
    include_once('../app/inventory/function/xadd_inventory.php');
    break;

case "inventory_edit";
    include_once('../app/inventory/inventory_edit.php');
    break;

case "xedit_inventory";
    include_once('../app/inventory/function/xedit_inventory.php');
    break;

case "inventory_delete";
    include_once('../app/inventory/function/xdelete_inventory.php');
    break;

case "inventory_view";
    include_once('../app/inventory/inventory_view.php');
    break;

case "backend_bakery";
    include_once('../app/bakery/bakery.php');
    break;

case "backend_carwash";
    include_once('../app/carwash/carwash.php');
    break;

case "backend_cashup";
    include_once('../app/cashup/cashup.php');
    break;

case "cashup_add";
    include_once('../app/cashup/cashup_add.php');
    break;

case "xadd_cashup";
    include_once('../app/cashup/function/xadd_cashup.php');
    break;

case "cashup_edit";
    include_once('../app/cashup/cashup_edit.php');
    break;

case "xedit_cashup";
    include_once('../app/cashup/function/xedit_cashup.php');
    break;

case "cashup_delete";
    include_once('../app/cashup/function/xdelete_cashup.php');
    break;

case "backend_fuel";
    include_once('../app/fuel/fuel.php');
    break;

case "fuel_add";
    include_once('../app/fuel/pumps/fuel_add.php');
    break;

case "xadd_fuel";
    include_once('../app/fuel/pumps/function/xadd_fuel.php');
    break;

case "fuel_edit";
    include_once('../app/fuel/pumps/fuel_edit.php');
    break;

case "xedit_fuel";
    include_once('../app/fuel/pumps/function/xedit_fuel.php');
    break;

case "fuel_delete";
    include_once('../app/fuel/pumps/function/xdelete_fuel.php');
    break;

case "tank_add";
    include_once('../app/fuel/tanks/tank_add.php');
    break;

case "xadd_tank";
    include_once('../app/fuel/tanks/function/xadd_tank.php');
    break;

case "tank_edit";
    include_once('../app/fuel/tanks/tank_edit.php');
    break;

case "xedit_tank";
    include_once('../app/fuel/tanks/function/xedit_tank.php');
    break;

case "tank_delete";
    include_once('../app/fuel/tanks/function/xdelete_tank.php');
    break;

case "backend_transactions";
    include_once('../app/transactions/transaction.php');
    break;

case "backend_notification";
    include_once('../app/notification/notification.php');
    break;

case "notification_add";
    include_once('../app/notification/notification_add.php');
    break;

case "xadd_notification";
    include_once('../app/notification/function/xadd_notification.php');
    break;

case "notification_edit";
    include_once('../app/notification/notification_edit.php');
    break;

case "xedit_notification";
    include_once('../app/notification/function/xedit_notification.php');
    break;

case "notification_delete";
    include_once('../app/notification/function/xdelete_notification.php');
    break;

}      

?>
