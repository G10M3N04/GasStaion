<?php
include '../root/includes/sidebar.php';
include __DIR__ . '/../../root/includes/validation_popup.php';
require_once "C:\Projects\gas.station\db\db_tank.php";

$acl_role = "Manager"; // Example role (change dynamically after login)
$tank_id = base64_decode($_GET["tank"]);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventory</title>
    <link rel="stylesheet" href="../includes/style.css">
</head>
<body class="inventory">

    <main class="main-content">
        <div>
        <?php include '../ui/dashboard/components/header.php'; ?>
        </div>
        <h1>Inventory</h1>
        <hr>
                <section class="fuel-section">
            <h2>Products</h2>
            <div class="fuel-inventory">
                <div class="tank diesel" onclick="window.location.href='http://gas.station:8081/?view=product_view&category=Beverages'"><h4>Beverages</h4></div>
                <div class="tank diesel" onclick="window.location.href='http://gas.station:8081/?view=product_view&category=Edible'"><h4>Edible</h4></div>
                <div class="tank unleaded" onclick="window.location.href='http://gas.station:8081/?view=product_view&category=Groceries'"><h4>Groceries</h4></div>
                <div class="tank unleaded" onclick="window.location.href='http://gas.station:8081/?view=product_view&category=Hygiene'"><h4>Hygiene</h4></div>
                <div class="tank unleaded" onclick="window.location.href='http://gas.station:8081/?view=product_view&category=Tobacco'"><h4>Tobacco</h4></div>
            </div>
        </section>
        <div>
        <?php include '../ui/dashboard/components/footer.php'; ?>
        </div>
    </main>
</body>
