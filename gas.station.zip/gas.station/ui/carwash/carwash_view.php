<?php
include_once '../db/db_connect.php';
$acl_role = "Manager"; // Example role (change dynamically after login)
include '../root/includes/sidebar.php';
include '../../root/includes/validation_popup.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Carwash</title>
    <link rel="stylesheet" href="../includes/style.css">
</head>
<body class="dashboard">

    <main class="main-content">
        <div>
        <?php include '../ui/dashboard/components/header.php'; ?>
        </div>
        <h1>Carwash</h1>
        <hr>

        <section class="stats">
            <div class="stat-card" onclick="window.location.href='http://gas.station:8081/?view=total_carwash_sales_view'">Carwash Sales<br>R0.00</div>
            <div class="stat-card" onclick="window.location.href='http://gas.station:8081/?view=carwash_type_view'">Carwash Types<br>R0.00</div>
        </section>
        <div>
        <?php include '../ui/dashboard/components/footer.php'; ?>
        </div>
    </main>
</body>
