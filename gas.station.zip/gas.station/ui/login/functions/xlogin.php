<?php 

require_once "C:\Projects\gas.station\db\db_person.php";
include '../root/includes/validation_popup.php';

$per_username = $_POST["username"];
$per_password = md5($_POST["password"]);

$person = new db_person();
$get_per_id = $person->getPersonByUsername($per_username);
$per_id = base64_encode($get_per_id->per_id);

if ($person->usernameExists($per_username) && $person->passwordExists($per_password)) {
        
    $msg = 'Login successfully';
    echo "
    <form id='go' action='http://gas.station:8081/?view=dashboard&id=$per_id' method='post'>
        <input type='hidden' name='popup_msg' value='$msg'>
    </form>
    <script>document.getElementById('go').submit();</script>
    ";
    popup($msg);

}else{
    
    $msg = 'Username or password incorrect';
    echo "
    <form id='go' action='http://gas.station:8081/?view=login' method='post'>
        <input type='hidden' name='popup_msg' value='$msg'>
    </form>
    <script>document.getElementById('go').submit();</script>
    ";
    popup($msg);
}

?>