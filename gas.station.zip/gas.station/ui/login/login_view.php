<?php

    include __DIR__ . '/../../root/includes/validation_popup.php';
// showPopup($_POST['popup_msg']);
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Gas Station</title>
</head>
<body>
    <div style="margin: 16% 34%" class="login-box">
        <h2>Login To Your Gas Station</h2>
        <form method="POST" action="http://gas.station:8081/?view=xlogin">
            <input type="text" name="username" placeholder="Enter Username" required>
            <input  type="password" name="password" placeholder="Enter Password" required>
            <button type="submit">Login</button>
        </form>
        <div class="link">
            <p>Don't have an account? <a href="http://gas.station:8081/?view=register">Register here</a></p>
        </div>
    </div>
</body>
</html>
