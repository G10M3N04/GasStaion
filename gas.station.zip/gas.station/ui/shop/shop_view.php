<?php
include_once '../../db/connection.php';
$acl_role = "Manager"; // Example role (change dynamically after login)
include '../root/includes/sidebar.php';
include '../../root/includes/validation_popup.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shop</title>
    <link rel="stylesheet" href="../includes/style.css">
</head>
<body class="dashboard">
    <main class="main-content">
        <div>
        <?php include '../ui/dashboard/components/header.php'; ?>
        </div>
        <h1>Shop</h1>
        <hr>

        <section class="stats">
            <div class="stat-card" onclick="window.location.href='http://gas.station:8081/?view=total_shop_sales_view'">Shop Sales<br>R0.00</div>
        </section>

                <section class="fuel-section">
            <h2>Products</h2>
            <div class="fuel-inventory">
                <div class="tank diesel" onclick="window.location.href='http://gas.station:8081/?view=product_view&category=Beverages'" ><h4>Beverages</h4></div>
                <div class="tank unleaded" onclick="window.location.href='http://gas.station:8081/?view=product_view&category=Groceries'" ><h4>Groceries</h4></div>
                <div class="tank unleaded" onclick="window.location.href='http://gas.station:8081/?view=product_view&category=Hygiene'"><h4>Hygiene</h4></div>
                <div class="tank unleaded" onclick="window.location.href='http://gas.station:8081/?view=product_view&category=Tobacco'"><h4>Tobacco</h4></div>
            </div>
        </section>
        <div>
        <?php include '../ui/dashboard/components/footer.php'; ?>
        </div>
    </main>
</body>
