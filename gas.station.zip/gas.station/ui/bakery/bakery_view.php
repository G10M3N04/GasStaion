<?php
include_once '../../db/connection.php';
$acl_role = "Manager"; // Example role (change dynamically after login)
include '../root/includes/sidebar.php';
include '../../root/includes/validation_popup.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Bakery</title>
    <link rel="stylesheet" href="../includes/style.css">
</head>
<body class="dashboard">

    <main class="main-content">
        <div>
        <?php include '../ui/dashboard/components/header.php'; ?>
        </div>
        <h1>Bakery</h1>
        <hr>

        <section class="stats">
            <div class="stat-card" onclick="window.location.href='http://gas.station:8081/?view=total_bakery_sales_view'">Bakery Sales<br>R0.00</div>
        </section>

        <section class="fuel-section">
            <h2>Products</h2>
            <div class="fuel-inventory">
                <div class="tank diesel" onclick="window.location.href='http://gas.station:8081/?view=product_view&category=Edible'"><h4>Edible</h4></div>
            </div>
        </section>
        <div>
        <?php include '../ui/dashboard/components/footer.php'; ?>
        </div>
    </main>
</body>
