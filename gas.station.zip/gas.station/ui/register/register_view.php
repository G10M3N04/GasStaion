<?php 

include __DIR__ . '/../../root/includes/validation_popup.php';

// showPopup($_POST['popup_msg']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Register Gas Station</title>
</head>
<body>
    <div class="register-box">
        <h2>Create Account</h2>
        
        <form method="POST" action="http://gas.station:8081/?view=xregister">
            <input type="text" name="firstname" placeholder="Enter First Name" required>

            <input type="text" name="lastname" placeholder="Enter Last Name" required>

            <input type="text" name="username" placeholder="Enter Username" required>

            <input type="email" name="email" placeholder="Enter Email" required>

            <input type="password" name="password" placeholder="Enter Password" required>

            <input type="password" name="confirm_password" placeholder="Confirm Password" required>

            <label>Select Role:</label>
            <select name="role" required>
                <option value="">-- Choose Role --</option>
                <option value="Owner">Owner</option>
                <option value="Manager">Manager</option>
                <option value="Attendant">Attendant</option>
                <option value="Cashier">Cashier</option>
                <option value="Carwasher">Carwasher</option>
            </select>

            <button type="submit">Register</button>
        </form>

        <div class="link">
            <p>Already have an account? <a href="http://gas.station:8081/?view=login">Login here</a></p>
        </div>
    </div>
</body>
</html>
<?php
    if (isset($_SESSION['error'])) {
        $error = $_SESSION['error'];
        echo "<script>alert('$error');</script>";
        unset($_SESSION['error']); // clear message so it doesn't show again
    }
?>
