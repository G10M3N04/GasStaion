<?php 
require_once "C:\Projects\gas.station\db\db_person.php";
require_once "C:\Projects\gas.station\db\db_person_role.php";
require_once "C:\Projects\gas.station\db\db_acl.php";
include '../root/includes/validation_popup.php';

$per_firstname = $_POST["firstname"];
$per_lastname = $_POST["lastname"];
$per_username = $_POST["username"];
$per_email = $_POST["email"];
$per_password = md5($_POST["password"]);
$per_confirm_password = md5($_POST["confirm_password"]);
$acl_role = $_POST["role"];

$acl_obj = new db_acl();
$acl = $acl_obj->getAclRole($acl_role);
$acl_id = $acl->acl_id;

$person = new db_person();
if (!$person->usernameExists($per_username) && !$person->emailExists($per_email) || !$person->usernameExists($per_username) || !$person->usernameExists($per_username))  

    {
    $person->set_default();

    $person->value_arr["per_firstname"] = $per_firstname;
    $person->value_arr["per_lastname"] = $per_lastname;
    $person->value_arr["per_username"] = $per_username;
    $person->value_arr["per_email"] = $per_email;
    $person->value_arr["per_password"] = $per_password;
    $person->value_arr["per_is_active"] = 1;
    
    $person->insert($person);

    $per_id = $person->getPersonByUsername($per_username)->per_id;
    if(!empty($per_id) && !empty($acl_id)){
        $person_role = new db_person_role();

        $person_role->set_default();

        $person_role->value_arr["prl_ref_acl"] = $acl_id;
        $person_role->value_arr["prl_ref_person"] = $per_id;

        $person_role->insert($person_role);

    }
    $msg = 'successfully registered';
    echo "
    <form id='go' action='Location: http://gas.station:8081/?view=login' method='post'>
        <input type='hidden' name='popup_msg' value='$msg'>
    </form>
    <script>document.getElementById('go').submit();</script>
    ";

    popup($msg);
    
    exit();

}else{

    $msg = 'Username or Email already exists. Please choose another one.';
    echo "
    <form id='go' action='http://gas.station:8081/?view=register' method='post'>
        <input type='hidden' name='popup_msg' value='$msg'>
    </form>
    <script>document.getElementById('go').submit();</script>
    ";
    popup($msg);
 
    exit();

}

?>
