<?php 
require_once __DIR__ . "/../../db/db_person.php";
require_once "C:\Projects\gas.station\db\db_person_role.php";
require_once __DIR__ . "/../../db/db_base.php";

$per_id = base64_decode($_GET["id"]);

$person_obj = new db_person();
$person = $person_obj->getPersonObjByID($per_id);

$person_role = new db_person_role();
$acl_id = $person_role->getPersonRoleById($per_id)->prl_ref_acl;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Profile</title>
</head>
<body>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Profile</title>
</head>

<div style="margin: 16% 34%" class="register-box">
        <a href="/?view=profile&id=<?= base64_encode($per_id) ?>" class="btn back">⬅ Back</a>
        <h2>Edit Profile</h2>
        <form method="POST" action="http://gas.station:8081/?view=xedit_profile&id=<?= base64_encode($per_id) ?>">
            <label>First Name</label>
            <input type="text" name="per_firstname" value="<?php echo $person->per_firstname; ?>" required>

            <label>Last Name</label>
            <input type="text" name="per_lastname" value="<?php echo $person->per_lastname; ?>" required>

            <label>Username</label>
            <input type="text" name="per_username" value="<?php echo $person->per_username; ?>" required>

            <label>ID number</label>
            <input type="text" name="per_idnr" value="<?php echo $person->per_idnr; ?>" required>

            <label>Email Address</label>
            <input type="text" name="per_email" value="<?php echo $person->per_email; ?>" required>

            <label>Phone Number</label>
            <input type="text" name="per_phone" value="<?php echo $person->per_phone; ?>" required>
            
            <label >Select Role:</label>
            <select name="role" required>
                <option  value="">-- Choose Role --</option>
                <option value="Owner" <?= $acl_id === '4'     ? 'selected' : '' ?>>Owner</option>
                <option value="Manager" <?= $acl_id === '3'     ? 'selected' : '' ?>>Manager</option>
                <option value="Attendant" <?= $acl_id === '8'     ? 'selected' : '' ?>>Attendant</option>
                <option value="Cashier" <?= $acl_id === '6'     ? 'selected' : '' ?>>Cashier</option>
                <option value="Carwasher" <?= $acl_id === '7'     ? 'selected' : '' ?>>Carwasher</option>
            </select>

            <button type="submit" action=""><a href="/?view=profile&id=<?= base64_encode($per_id) ?>" class="btn-icon">Edit</a></button>
        </form>
    </div>
</div>
</body>
</html>

