<?php

require_once __DIR__ . "/../../db/db_person.php";
require_once __DIR__ . "/../../db/db_acl.php";
require_once __DIR__ . "/../../db/db_person_role.php";

// Get person data
$personObj = new db_person();
$roleObj   = new db_person_role();
$aclObj    = new db_acl();

$per_id = base64_decode($_GET["id"]);
$person = $personObj->getPersonObjById($per_id);
$role   = $roleObj->getPersonRoleById($per_id);
$acl    = $aclObj->getAclRole($role->prl_ref_acl);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Profile</title>
</head>
<body>
    <div class="profile-container">

    <div class="profile-card">
        <div class="profile-header">
            <img src="../includes/assets/default_profile.jpg" class="profile-pic">
            <h2><?= $person->per_firstname . " " . $person->per_lastname ?></h2>
            <span class="role-tag"><?= $acl->acl_role ?></span>
        </div>

        <div class="profile-details">
            <div class="profile-row">
                <label>ID Number</label>
                <span><?= $person->per_idnr ?></span>
            </div>

            <div class="profile-row">
                <label>Email</label>
                <span><?= $person->per_email ?></span>
            </div>

            <div class="profile-row">
                <label>Phone</label>
                <span><?= $person->per_phone ?></span>
            </div>

            <div class="profile-row">
                <label>Status</label>
                <span><?= $person->per_is_active ? "Active" : "Inactive" ?></span>
            </div>
        </div>

        <div class="profile-actions">
            <a href="/?view=edit_profile&id=<?= base64_encode($per_id) ?>" class="btn edit">✏ Edit</a>
            <a href="/?view=dashboard&id=<?= base64_encode($per_id) ?>" class="btn back">⬅ Back</a>
        </div>
    </div>

</div>
</body>
</html>

