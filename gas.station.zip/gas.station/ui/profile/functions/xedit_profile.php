<?php

require_once "C:/Projects/gas.station/db/db_person.php";
require_once "C:\Projects\gas.station\db\db_person_role.php";
require_once "C:\Projects\gas.station\db\db_acl.php";
include '../root/includes/validation_popup.php';

$per_id = $_GET["id"];

$person_role = new db_person_role();
$prl_id = $person_role->getPersonRoleId($per_id);

$person_obj = new db_person();
$person = $person_obj->getPersonObjByID(base64_decode($per_id));

$per_firstname = $_POST["per_firstname"];
$per_lastname = $_POST["per_lastname"];
$per_firstname = $_POST["per_username"];
$per_email = $_POST["per_email"];
$per_idnr = $_POST["per_idnr"];
$per_phone = $_POST["per_phone"];
$role = $_POST["role"];


$person_obj = new db_person();
$person_obj->set_default();

$person_obj->value_arr["per_id"] = base64_decode($per_id);
$person_obj->value_arr["per_firstname"] = $per_firstname;
$person_obj->value_arr["per_lastname"] = $per_lastname;
$person_obj->value_arr["per_username"] = $per_lastname;
$person_obj->value_arr["per_email"] = $per_email;
$person_obj->value_arr["per_idnr"] = $per_idnr;
$person_obj->value_arr["per_phone"] = $per_phone;
$person_obj->value_arr["per_password"] = $person->per_password;

// 81dc9bdb52d04dc20036dbd8313ed055
// $person_obj->update($person_obj);

$acl_obj = new db_acl();
$acl = $acl_obj->getAclIdByRole($role);

$person_role_obj = new db_person_role();
$person_role_obj->set_default();

// $person_role_obj->value_arr["prl_id"] = $prl_id;
$person_role_obj->value_arr["prl_ref_acl"] = $acl->acl_id;
$person_role_obj->value_arr["prl_ref_person"] = base64_decode($per_id);

print_r($person_role_obj);
exit();
$person_role_obj->update($person_role_obj);

    // $msg = 'Login successfully';
    echo "
    <form id='go' action='http://gas.station:8081/?view=xedit_profile&id=$per_id' method='post'>
        <input type='hidden' name='popup_msg' value=''>
    </form>
    <script>document.getElementById('go').submit();</script>
    ";
    // popup($msg);

header("Location: index.php?view=profile&id=$per_id")


?>
