<?php
require_once "C:\Projects\gas.station\db\db_acl.php";
require_once "C:\Projects\gas.station\db\db_person_role.php";

$currentPage = basename($_SERVER['PHP_SELF']);
$per_id = base64_decode($_SESSION['per_id']);


$personObj = new db_person();
$roleObj   = new db_person_role();
$aclObj    = new db_acl();

$per_id = base64_decode($_GET["id"]);
$person = $personObj->getPersonObjById($per_id);
$role   = $roleObj->getPersonRoleById($per_id);
$acl    = $aclObj->getAclRole($role->prl_ref_acl);

?>
<header class="top-header">
  <div class="header-breadcrumb">
    <i class="ti ti-home" aria-hidden="true"></i>
    <a href="/?view=dashboard" ></a>
    <span class="breadcrumb-sep"></span>
    <span class="current"></span>
  </div>

  <div class="header-right">
    <div class="status-badge">
      <span class="status-dot" aria-hidden="true"></span>
      <i>All Systems online</i>
    </div>

    <a class="icon-btn" title="Notifications" aria-label="Notifications" href="/?view=notification_log_view">
      <p class="ti ti-bell" aria-hidden="true">&#128276;</p>
      <span class="notif-dot" aria-hidden="true"></span>
    </a>

    <a href="/?view=profile&id=<?= $_SESSION['per_id'] ?>" class="user-chip">
      <div class="user-avatar" aria-hidden="true">
        &#125935;     
      </div> 
      <span class="user-name" title="Profile" aria-label="View Profile"><?= $person->per_firstname . " " . $person->per_lastname ?></span>
      <i class="ti ti-chevron-down"
         style="font-size:13px;color:rgba(255,255,255,.6)"
         aria-hidden="true">
        </i>
    </a>
  </div>
</header>

<script>
    const fitToggleBtn = document.getElementById('fit-toggle-btn');

    fitToggleBtn.addEventListener('click', () => {
        document.body.classList.toggle('fit-page');
        const active = document.body.classList.contains('fit-page');
        fitToggleBtn.setAttribute('aria-pressed', active ? 'true' : 'false');
        fitToggleBtn.style.background = active ? 'rgba(255,255,255,.3)' : 'rgba(255,255,255,.1)';
    });
</script>