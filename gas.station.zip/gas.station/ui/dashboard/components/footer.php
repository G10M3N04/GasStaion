<?php
require_once "C:\Projects\gas.station\db\db_acl.php";
require_once "C:\Projects\gas.station\db\db_person_role.php";

$currentPage = basename($_SERVER['PHP_SELF']);
$per_id = base64_decode($_SESSION['per_id']);

$person_role = new db_person_role();

$acl = new db_acl();
$acl_id = $person_role->getPersonRoleById($per_id)->prl_ref_acl;
$acl_role = $acl->getAclRole($acl_id)->acl_role;

?>
<footer class="page-footer">
  <nav class="footer-links" aria-label="Footer navigation">
    <a href="?view=help">Help &amp; Support</a>
    <a href="?view=privacy">Privacy Policy</a>
    <a href="?view=terms">Terms of Use</a>
    <a href="?view=contact">Contact</a>
  </nav>
  <div class="footer-right">
    <i class="ti ti-copyright" style="font-size:13px" aria-hidden="true"></i>
    <?= date('Y') ?> GasStation Management System &middot; All rights reserved
    &middot; 
  </div>
</footer>