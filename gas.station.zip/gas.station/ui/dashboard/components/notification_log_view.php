<?php
require_once "C:\Projects\gas.station\db\db_notifications.php";

$id   = $_GET['per_id'];

$notifications_obj = new db_notification();
$notifications = $notifications_obj->getAllNotifications();


?>

<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Notification Logs</title>
    

    <style>
        body{
            font-family: Arial, sans-serif;
            background:#f4f4f4;
            padding:20px;
        }

        .container{
            width:90%;
            margin:auto;
        }

        h2{
            color:#333;
        }

        table{
            width:100%;
            border-collapse:collapse;
            background:white;
        }

        th{
            background:#007bff;
            color:white;
            padding:12px;
            text-align:left;
        }

        td{
            padding:10px;
            border-bottom:1px solid #ddd;
        }

        tr:hover{
            background:#f9f9f9;
        }

        .unread{
            color:red;
            font-weight:bold;
        }

        .read{
            color:green;
        }

        .badge{
            padding:5px 10px;
            border-radius:5px;
            color:white;
            font-size:12px;
        }

        .Fuel { background:#dc3545; }
        .Sales { background:#28a745; }
        .System { background:#6c757d; }
        .User { background:#17a2b8; }
    </style>
</head>
<body>

<div class="container">

    <h2>Gas Station Notification Logs</h2>
    <a href="index.php?view=dashboard&id=<?= $id ?>" class="btn btn-primary">Back </a>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Type</th>
                <th>Message</th>
                <th>Status</th>
                <th>Date & Time</th>
            </tr>
        </thead>

        <tbody>

        <?php if(count($notifications) > 0): ?>

            <?php foreach($notifications as $not): ?>

                <tr>
                    <td><?= $not->not_id; ?></td>

                    <td>
                        <span class="badge <?= htmlspecialchars($not->not_type); ?>">
                            <?= htmlspecialchars($not->not_type); ?>
                        </span>
                    </td>

                    <td><?= htmlspecialchars($not->not_message); ?></td>

                    <td class="<?= strtolower($not->not_status) ?>">
                        <?= $not->not_status; ?>
                    </td>

                    <td><?= $not->not_date; ?></td>
                </tr>

            <?php endforeach; ?>

        <?php else: ?>

            <tr>
                <td colspan="5" style="text-align:center;">
                    No notifications found.
                </td>
            </tr>

        <?php endif; ?>

        </tbody>
    </table>

</div>

</body>
</html>