<?php

require_once "C:\Projects\gas.station\db\db_tank.php";
require_once "C:\Projects\gas.station\db\db_person.php";
require_once "C:\Projects\gas.station\db\db_person_role.php";
require_once "C:\Projects\gas.station\db\db_acl.php";
include '../root/includes/validation_popup.php';
require "C:\Projects\gas.station\ui\dashboard\stats\stat_cards.php";

$tank_obj = new db_tank();
$tanks = $tank_obj->getAllTankObj();

$person_obj = new db_person();
$per_id = base64_decode($_GET["id"]);

$person_role = new db_person_role();
$prl_id = $person_role->getPersonRoleById($per_id);

$acl = new db_acl();
$acl_level = $acl->getAclId($prl_id->prl_ref_acl);
// $acl_role = $acl->getAclRole($acl_level)->acl_role;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../includes/style.css">
</head>
<body class="dashboard">
    
    <main class="main-content">
        <div>
        <?php include '../root/includes/sidebar.php'; ?>
        <?php include '../ui/dashboard/components/header.php'; ?>
        </div>
        <h1>Dashboard</h1>
        <hr>

        <!-- Revenue Stat Cards -->
        <section class="stats">
        <div><?php echo showStatCards($acl_role); ?></div>
        </section>

        <!-- Tank Stat Cards -->
        <section class="fuel-section">
            <h2>Fuel Inventory</h2>
            <div class="fuel-inventory">
                <?php
                foreach($tanks as $tank){

                ?>
                    <div onclick = "window.location.href= 'index.php?view=tank_view&tank=<?php echo base64_encode($tank->tnk_id) ?>&id=<?= base64_encode($per_id) ?>'" class="tank <?php echo $tank->tnk_type ?>">
                        <h4>Tank <?php echo $tank->tnk_id . " - " .  $tank->tnk_type ?></h4>
                        <!-- <p><?php $tank->tnk_type?> Fuel Level</p>
                        <p>Current<br><span><?php echo number_format($tank->tnk_fuel_volume,0) ?> L</span></p> -->
                    </div>

                <?php
                }              
                ?>
            </div>
        </section>
        <div>
        <?php include '../ui/dashboard/components/footer.php'; ?>
        </div>
    </main>
</body>
