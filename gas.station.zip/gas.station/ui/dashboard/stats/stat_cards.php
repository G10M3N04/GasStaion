<?php
include_once "../db/connection.php";
require_once "C:\Projects\gas.station\db\db_cashup.php";

function showStatCards($acl_role){

    $stat_cards = [

        "Todays Revenue" => [
            "result" => "50000",
            "view" => "total_revenue_view"
        ],

        "Total Fuel Sold" => [
            "result" => "2000L",
            "view" => "total_fuel_sold_view"
        ],

        "Active Pumps" => [
            "result" => "6",
            "view" => "active_pumps_view"
        ],

        "Total Shop Sales" => [
            "result" => "50000",
            "view" => "total_shop_sales_view"
        ],

        "Total Bakery Sales" => [
            "result" => "50000",
            "view" => "total_bakery_sales_view"
        ],

        "Total Carwash Sales" => [
            "result" => "50000",
            "view" => "total_carwash_sales_view"
        ],
    ];
            $html = "<div class='stats'>";

    foreach($stat_cards as $index=>$stats){


        switch ($acl_role) {

            case "Manager":
            case "Owner":
            case "Dev": 
                $html .= statCard($index, $stats);
                break;

            case "Cashier": 
                if($index == "Total Shop Sales" || $index == "Total Bakery Sales")
                $html .= statCard($index, $stats);
                break;

            case "Carwasher": 
                if($index == "Total Carwash Sales")
                $html .= statCard($index, $stats);
                break;

            case "Attendant": 
                if($index == "Total Fuel Sold" || $index == "Active Pumps")
                $html .= statCard($index, $stats);
                break;

        }

    }
        $html .= "</div>";

    return $html;

}

function statCard($title, $stats)
{
    $per_id = $_GET['id'];
    $onclick = "'index.php?view={$stats['view']}&id=$per_id'";

    return "
        <div onclick=\"window.location.href=$onclick\" class='stat-card'>
            <div style='font-size: 16px; font-weight: bold;'>
                <h4>{$title}</h4>
                <p>{$stats['result']}</p>
            </div>
        </div>
    ";

}
?>