<?php

// include "/db/connection.php";
require_once __DIR__. '/../../../root/includes/error_handler.php';
require_once "C:\Projects\gas.station\db\db_tank.php";
require_once __DIR__. '/../../../root/includes/validation_popup.php';

$per_id = $_GET["id"];                
$tank_id = base64_decode($_GET["tank"]);

$tank_obj = new db_tank();
$tank = $tank_obj->getTankById($tank_id);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Fuel Tank Overview</title>
    <link rel="stylesheet" href="../includes/style.css">

</head>

<body>
<a href="index.php?view=dashboard&id=<?= $per_id ?>" class="btn btn-primary">Back </a>
<h1>Fuel Tank Overview</h1>

     <?php
        $capacity =  7000; //$tank->tnk_capacity;
        $current  = $tank['tnk_fuel_volume'];

        $percentage = ($capacity > 0) ? round(($current / $capacity) * 100, 2) : 0;
        $status = $tank_obj->getStatus($percentage);
        $statusClass = strtolower($status);

        if($percentage <= 5 || $percentage <= 20) {
            popup("Fuel running low! or Tank is Empty");
        }

    ?>

    <div class="tank-card">

        <h2><?php echo $tank['tnk_type']; ?></h2>

        <p><b>Fuel Type:</b> <?php echo $tank['tnk_type']; ?></p>
        <p><b>Tank Capacity:</b> <?php echo $capacity; ?> L</p>
        <p><b>Current Volume:</b> <?php echo $current; ?> L</p>
        <p><b>Percentage:</b> <?php echo $percentage; ?>%</p>

        <p>
            <b>Status:</b>
            <span class="status <?php echo $statusClass; ?>">
                <?php echo $status; ?>
            </span>
        </p>

        <p><b>Last Refill Date:</b> <?php echo "last_refill_date"; ?></p>

        <!-- Progress bar -->
        <div class="progress-container">
            <div class="progress-bar" style="width: <?php echo $percentage; ?>%; background:
                <?php
                    if ($percentage <= 5) echo 'red';
                    elseif ($percentage <= 20) echo 'orange';
                    elseif ($percentage == 50) echo 'yellow';
                    else echo 'green';
                ?>;">
            </div>
        </div>

    </div>


</body>
</html>
