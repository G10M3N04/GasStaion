<?php

// $acl_role = "Manager"; // Example role (change dynamically after login)
include '../../root/includes/error_handler.php';
$per_id = $_GET["id"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Total Fuel Sold</title>
    <link rel="stylesheet" href = "../includes/style.css">
</head>
<body>
<a href="index.php?view=dashboard&id=<?= $per_id ?>" class="btn btn-primary">Back </a>
<div class="wrapper">

    <div class="card">
        <h2>Total Fuel Sold</h2>
        <p class="big-number"><?= number_format($fuelSold, 2) ?> L</p>
    </div>
</div>

</body>
