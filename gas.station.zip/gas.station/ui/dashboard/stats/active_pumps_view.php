<?php


$acl_role = "Manager"; // Example role (change dynamically after login)
include '../../root/includes/error_handler.php';
require_once "C:\Projects\gas.station\db\db_fuel_pump.php";

$fuel_pump_default = new db_fuel_pump();
$fuel_pump_obj = $fuel_pump_default->getActivePump();

$per_id = $_GET["id"]; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Active Pumps</title>
    <link rel="stylesheet" href="../includes/style.css">
</head>
<body>
<a href="index.php?view=dashboard&id=<?= $per_id ?>" class="btn btn-primary">Back </a>
<div class="wrapper">

    <div class="card">
        <h2>Active Pumps</h2>
        <p class="big-number"><?= $fuel_pump_obj->flp_is_active ?></p>
    </div>

</div>

</body>
