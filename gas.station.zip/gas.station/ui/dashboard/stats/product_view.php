<?php
require_once "C:\Projects\gas.station\db\db_product.php";
require_once __DIR__. '/../../../root/includes/error_handler.php';
$product_category = $_GET["category"];
$product_obj = new db_product();
$products = $product_obj->getProductsByCategory($product_category);


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Products</title>
    <style>
        body { font-family: Arial; background: #f7f7f7; padding: 20px; }
        .category {
            background: white;
            margin-bottom: 25px;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
        }
        h2 { margin-top: 0; }
        table { width: 100%; border-collapse: collapse; }
        th, td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        th { background: #fafafa; text-align: left; }
    </style>
</head>
<body>

<h1>Product List</h1>

<h2><?php echo $product_category; ?></h2>
<?php foreach ($products as $product): ?>
    <div class="category">
        <table>
            <tr>
                <th>Name</th>
                <th>Price (R)</th>
                <th>Quantity</th>
            </tr>

            <tr>
                <td><?php echo $product->pro_name ?></td>
                <td>R<?php echo  number_format($product->pro_price, 2) ?></td>
                <td><?php echo $product->pro_quantity ?></td>
            </tr>

        </table>
    </div>
<?php endforeach; ?>

</body>
</html>
