<?php

// require_once "../db/connection.php"; // Your PDO SQLSRV connection
include '../../root/includes/error_handler.php';
include_once '/db/db_acl.php';

$per_id = $_GET["id"];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Gas Station Revenue Analytics</title>
    <link rel="stylesheet" href="../includes/style.css">
</head>

<body>
<a href="index.php?view=dashboard&id=<?= $per_id ?>" class="btn btn-primary">Back </a>
<div class="wrapper">

    <div class="card">
        <h2>Total Fuel Sold</h2>
        <p class="big-number">R <?= number_format($fuelSold, 2) ?> </p>
    </div>

    <div class="card">
        <h2>Bakery Sales</h2>
        <p class="big-number">R <?= number_format($bakerySales, 2) ?></p>
    </div>

    <div class="card">
        <h2>Shop Sales</h2>
        <p class="big-number">R <?= number_format($shopSales, 2) ?></p>
    </div>

    <div class="card">
        <h2>Carwash Sales</h2>
        <p class="big-number">R <?= number_format($carwashSales, 2) ?></p>
    </div>

    <div class="card">
        <h2>Total Revenue for Today</h2>
        <p class="big-number">R <?= number_format($carwashSales, 2) ?></p>
    </div>
</div>

</body>
</html>
