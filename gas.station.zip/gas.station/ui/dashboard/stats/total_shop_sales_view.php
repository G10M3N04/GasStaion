<?php


// $acl_role = "Manager"; // Example role (change dynamically after login)
// include '../root/includes/validation_popup.php';
include '../../root/includes/error_handler.php';

// showPopup();
$per_id = $_GET["id"];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Total Shop Sales</title>
    <link rel="stylesheet" href="../includes/style.css">
</head>
<body>
<a href="index.php?view=dashboard&id=<?= $per_id ?>" class="btn btn-primary">Back </a>
<div class="wrapper">
    <div class="card">
        <h2>Shop Sales</h2>
        <p class="big-number"  >R <?= number_format($shopSales, 2) ?></p>
    </div>
</div>

</body>
