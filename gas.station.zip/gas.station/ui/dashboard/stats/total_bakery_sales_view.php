<?php

include '../../root/includes/error_handler.php';

$per_id = $_GET["id"]; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Total Bakery Sales</title>
    <link rel="stylesheet" href="../includes/style.css">
</head>
<body>
<a href="index.php?view=dashboard&id=<?= $per_id ?>" class="btn btn-primary">Back</a>
<div class="wrapper">

    <div class="card">
        <h2>Bakery Sales</h2>
        <p class="big-number">R <?= number_format($bakerySales, 2) ?></p>
    </div>
</div>

</body>
