<?php

include '../root/includes/validation_popup.php';
$per_id = $_GET["id"];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Add Notification</title>
</head>
<body>
    <div class="content">
    <h3>Add Notification</h3>

    <form method="POST" action="index.php?view=xadd_notification&id=<?= $per_id?>" class="sys-form">

        <label>Notification Title</label>
        <input type="text" name="not_title" required>

        <label class="category-box" >Select Notification Type:</label>
            <select name="not_type" required>
                <option value="">-- Choose Notification Type --</option>
                <option value="Alert">Alert</option>
                <option value="SMS">SMS</option>
            </select>

        <label>Notification Message</label>
        <input type="text" name="not_message" required>

        <label>Notification date</label>
        <input type="date" name="not_date" required>

        <button type="submit" class="add-btn">Add Notification</button>

    </form>
</div>
</body>
</html>