<?php

include '../root/includes/validation_popup.php';
require_once "C:/Projects/gas.station/db/db_notifications.php";

$per_id = $_GET["id"];
$not_id = base64_decode($_GET["msg_id"]);

$not_obj = new db_notification();
$not = $not_obj->getNotificationObjByID($not_id);
$date=date_create($not->not_date);
$selected = "selected";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Edit Notification</title>
</head>
<body>
    <div class="content">
    <h3>Edit Notification</h3>

    <form method="POST" action="index.php?view=xedit_notification&id=<?= $per_id?>&msg_id=<?= base64_encode($not_id)?>" class="sys-form">

        <label>Notification Title</label>
        <input type="text" name="not_title" value="<?= $not->not_title ?>" required>

        <label class="category-box" >Select Notification Type:</label>
            <select name="not_type" required>

                <option <?if($not->not_type == "") echo $selected ?> value="">-- Choose Notification Type --</option>
                <option <?if($not->not_type == "Alert") echo $selected ?> value="Alert">Alert</option>
                <option <?if($not->not_type == "SMS") echo $selected ?> value="SMS">SMS</option>
            </select>

        <label>Notification Message</label>
        <input type="text" name="not_message" value="<?= $not->not_message ?>" required>
        <label>Notification date</label>
        <input type="date" name="not_date" value="<?=  date_format($date,"Y-m-d") ?>" required>

        <button type="submit" class="add-btn">Edit Notification</button>

    </form>
</div>
</body>
</html>