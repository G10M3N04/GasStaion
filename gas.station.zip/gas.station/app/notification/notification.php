<?php

include '../app/assets/header.php';
include '../app/assets/tab_bar.php';
require_once "C:\Projects\gas.station\db\db_notifications.php";

$per_id = $_GET["id"];

$not_obj = new db_notification();
$notification = $not_obj->getAllNotifications();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Dashboard Overview</title>
</head>
<div class="page-container">
    <div class="page-title-bar">
        <h3>Notifications</h3>
        <a href="index.php?view=notification_add&id=<?= $per_id ?>" class="add-btn">Add Notification</a>
    </div>

    <table class="table-list">
        <thead>
            <tr>
                <th>Action</th>
                <th>Title</th>
                <th>Type</th>
                <th>Message</th>
                <th>Date</th>
            </tr>
        </thead>

        <tbody>
        <?php foreach ($notification as $not): 
            print_r($not->not_id);?>
            <tr>   
                <td class="actions">
                    <a href="index.php?view=notification_edit&msg_id=<?= base64_encode($not->not_id) ?>&id=<?= $per_id ?>">✏️</a>
                    <a href="index.php?view=notification_delete&msg_id=<?= base64_encode($not->not_id) ?>&id=<?= $per_id ?>">🗑️</a>
                </td>
                <td><?= $not->not_title ?></td>
                <td><?= $not->not_type ?></td>
                <td><?= $not->not_message ?></td>
                <td><?= $not->not_date ?></td>        
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
</html>