<?php

require_once "C:/Projects/gas.station/db/db_notifications.php";
include '../root/includes/validation_popup.php';

$per_id = $_GET["id"];
$not_id = base64_decode($_GET["msg_id"]);

$not_obj = new db_notification();
$not_obj->set_default();
$not_obj->value_arr["not_id"] = $not_id;

$not_obj->delete($not_obj);

    // $msg = 'Login successfully';
    echo "
    <form id='go' action='http://gas.station:8081/?view=backend_notification&id=$per_id' method='post'>
        <input type='hidden' name='popup_msg' value=''>
    </form>
    <script>document.getElementById('go').submit();</script>
    ";
    // popup($msg);

header("Location: index.php?view=backend_notification&id=$per_id")

?>
