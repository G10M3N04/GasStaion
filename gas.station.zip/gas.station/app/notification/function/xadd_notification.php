<?php

require_once "C:/Projects/gas.station/db/db_notifications.php";
include '../root/includes/validation_popup.php';

$per_id = $_GET["id"];
$not_ref_person = base64_decode($_GET["id"]);

$not_title  = $_POST["not_title"];
$not_type   = $_POST["not_type"] ?? '';
$not_message   = $_POST["not_message"];
$not_date  = $_POST["not_date"];

$not_obj = new db_notification();
$not_obj->set_default();

$not_obj->value_arr["not_ref_person"] = $not_ref_person;
$not_obj->value_arr["not_title"] = $not_title;
$not_obj->value_arr["not_type"]  = $not_type;
$not_obj->value_arr["not_message"]      = $not_message;
$not_obj->value_arr["not_date"]     = $not_date;
$not_obj->value_arr["not_is_active"] = 1;

$not_obj->insert($not_obj);

    // $msg = 'Login successfully';
    echo "
    <form id='go' action='http://gas.station:8081/?view=backend_notification&id=$per_id' method='post'>
        <input type='hidden' name='popup_msg' value=''>
    </form>
    <script>document.getElementById('go').submit();</script>
    ";
    // popup($msg);

header("Location: index.php?view=backend_notification&id=$per_id")

?>
