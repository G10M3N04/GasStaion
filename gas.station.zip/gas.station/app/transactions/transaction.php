<?php
include '../app/assets/header.php';
include '../app/assets/tab_bar.php';
require_once "C:/Projects/gas.station/db/db_transactions.php";

$tns_obj = new db_transactions();
$transactions = $tns_obj->getAllTransactions();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Transactions</title>
</head>
<body>
    <div class="container mt-4">
    <h2>Gas Station Transactions</h2>

<a href="../transactions/import_transactions.php" class="btn"></a>
<table border="1" cellpadding="8" cellspacing="0">
        <tr>
            <th>ID</th>
            <th>Fuel Pump</th>
            <th>Type</th>
            <th>Description</th>
            <th>Amount</th>
            <th>Person</th>
            <th>Date</th>
        </tr>

        <?php foreach ($transactions as $t): ?>
            <tr>
                <td><?= $t->tns_id ?></td>
                <td><?= $t->tns_ref_fuel_pump ?></td>
                <td><?= $t->tns_type ?></td>
                <td><?= $t->tns_description ?></td>
                <td>R<?= number_format($t->tns_amount, 2) ?></td>
                <td><?= $t->tns_ref_person ?></td>
                <td><?= $t->tns_date ?></td>
            </tr>
        <?php endforeach; ?>

</table>
</div>

</body>
</html>
