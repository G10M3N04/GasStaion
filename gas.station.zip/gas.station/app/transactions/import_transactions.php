<?php

include_once "../db/connection.php";

$conn = db_connection::connection();

// Load JSON file
$jsonPath = __DIR__."/app/transactions/transactions.json";
$json = file_get_contents($jsonPath);
$data = json_decode($json, true);

if ($data === null) {
    die("Invalid JSON file");
}

$sql = "INSERT INTO transactions (
            tns_ref_cashup,
            tns_ref_person,
            tns_ref_products,
            tns_ref_fuel_pump,
            tns_type,
            tns_description,
            tns_amount,
            tns_date
        ) VALUES (
            :cashup,
            :person,
            :products,
            :fuel_pump,
            :fuel_type,
            :description,
            :amount,
            :date
        )";

$stmt = $conn->prepare($sql);

foreach ($data as $row) {

    $stmt->execute([
        ':cashup'      => isset($row['cashup']) ? $row['cashup'] : null,
        ':person'      => isset($row['cashier']) ? $row['cashier'] : null,
        ':products'    => isset($row['product_ref']) ? $row['product_ref'] : null,
        ':fuel_pump'   => $row['pump_number'],
        ':type'        => $row['fuel_type'],
        ':description' => isset($row['description']) ? $row['description'] : null,
        ':amount'      => $row['total_amount'],
        ':date'        => $row['timestamp']
    ]);
}

echo "Transactions imported successfully!";
