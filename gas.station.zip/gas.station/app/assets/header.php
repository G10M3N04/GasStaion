<?php 
require_once "C:\Projects\gas.station\db\db_acl.php";
require_once "C:\Projects\gas.station\db\db_person_role.php";
require_once "C:\Projects\gas.station\db\db_person.php";

$person_obj = new db_person();
$per_id = base64_decode($_GET['id']);
$person = $person_obj->getPersonByID($per_id);

$person_role = new db_person_role();

$acl = new db_acl();
$acl_id = $person_role->getPersonRoleById($per_id)->prl_ref_acl;
$acl_role = $acl->getAclRole($acl_id)->acl_role;

?>
<div class="sys-header">
    <strong><?= $pageTitle ?? "System Overview" ?></strong>
    <div class="container">
        <div class=".item"><?= $person->per_firstname ." ".  $person->per_lastname ?></div>
        <div class=".item">Logged in as: <?= $acl_role ?>
    </div>
</div>
</div>
