<?php

require_once 'alert.php';

if (isset($_SESSION['alert'])) {

    echo Alert::show(
        $_SESSION['alert']['type'],
        $_SESSION['alert']['message']
    );

    unset($_SESSION['alert']);
}
?>