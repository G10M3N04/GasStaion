<?php

class Alert
{
    public static function show($type, $message): string
    {
        $alertClasses = [
            'success' => 'alert-success',
            'danger'  => 'alert-danger',
            'warning' => 'alert-warning',
            'info'    => 'alert-info'
        ];

        $class = $alertClasses[$type] ?? 'alert-info';

        return "
            <div class='alert {$class} alert-dismissible fade show' role='alert'>
                {$message}
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            </div>
        ";
    }
}
?>