<?php
$id   = $_GET['id'] ?? 0;
$view = $_GET['view'] ?? "dashboard";

$tabs = [
    "dashboard" => ["icon" => "📊", "label" => "Dashboard", 'link' => "app&id={$_SESSION['per_id']}"],
    "person"    => ["icon" => "👤", "label" => "Person", 'link' => "backend_person&id={$_SESSION['per_id']}"],
    "transactions"      => ["icon" => "🏧", "label" => "Transactions", 'link' => "backend_transactions&id={$_SESSION['per_id']}"],
    "bakery"    => ["icon" => "🍪", "label" => "Bakery", 'link' => "backend_bakery&id={$_SESSION['per_id']}"],
    "inventory" => ["icon" => "📦", "label" => "Inventory", 'link' => "backend_inventory&id={$_SESSION['per_id']}"],
    "cashups"   => ["icon" => "🧾", "label" => "Cashup", 'link' => "backend_cashup&id={$_SESSION['per_id']}"],
    "fuel"   => ["icon" => "⛽", "label" => "Fuel", 'link' => "backend_fuel&id={$_SESSION['per_id']}"],
    "notifications"   => ["icon" => "🔔", "label" => "Notifications", 'link' => "backend_notification&id={$_SESSION['per_id']}"]
];
?>

<nav class="tabbar">
    <a href="index.php?view=dashboard&id=<?= $id ?>" class="btn btn-primary">Back </a>
    <?php foreach ($tabs as $key => $item): ?>
        <a href="index.php?view=<?= $item['link'] ?>"
           class="<?= $view === $key ? 'active' : '' ?>">
            <?= $item["icon"] ?> <?= $item["label"] ?>
        </a>
    <?php endforeach; ?>
</nav>
