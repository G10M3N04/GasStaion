<?php

include '../root/includes/validation_popup.php';
require_once "C:\Projects\gas.station\db\db_person.php";

$per_id = base64_decode($_GET["id"]);

$person_obj = new db_person();
$person = $person_obj->getPersonObjByID($per_id);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Edit Person</title>
</head>
<body>
    <div class="content">
    <h3>Edit Person</h3>

    <form method="POST" action="http://gas.station:8081/?view=xedit_person&id=<?= base64_encode($per_id) ?>" class="sys-form">

        <label>First Name</label>
        <input type="text" name="per_firstname" value="<?php echo $person->per_firstname; ?>" required>

        <label>Last Name</label>
        <input type="text" name="per_lastname" value="<?php echo $person->per_lastname; ?>" required>

        <label>ID Number</label>
        <input type="text" name="per_idnr" value="<?php echo $person->per_idnr; ?>" required>

        <label>Phone</label>
        <input type="text" name="per_phone" value="<?php echo $person->per_phone; ?>" required>

        <label>Email</label>
        <input type="email" name="per_email" value="<?php echo $person->per_email; ?>" required>

        <label>Date Of Birth</label>
        <input type="date" name="per_dob" value="<?php echo $person->per_dob; ?>" required>

        <label>Gender</label>
        <input type="text" name="per_gender" value="<?php echo $person->per_gender; ?>" required>

        <label>Ethnicity</label>
        <input type="text" name="per_ethnicity" value="<?php echo $person->per_ethnicity; ?>" required>

        <button type="submit" class="add-btn">Save Person</button>

    </form>
</div>
</body>
</html>