<?php

include '../root/includes/validation_popup.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Add Person</title>
</head>
<body>
    <div class="content">
    <h3>Add Person</h3>

    <form method="POST" action="index.php?view=xadd_person" class="sys-form">

        <label>First Name</label>
        <input type="text" name="per_firstname" required>

        <label>Last Name</label>
        <input type="text" name="per_lastname" required>

        <label>ID Number</label>
        <input type="text" name="per_idnr" required>

        <label>Phone</label>
        <input type="text" name="per_phone" required>

        <label>Email</label>
        <input type="email" name="per_email" required>

        <label>Date Of Birth</label>
        <input type="date" name="per_dob" required>

        <label>Gender</label>
        <input type="text" name="per_gender" required>

        <label>Ethnicity</label>
        <input type="text" name="per_ethnicity" required>

        <button type="submit" class="add-btn">Save Person</button>

    </form>
</div>
</body>
</html>