<?php

include '../app/assets/header.php';
include '../app/assets/tab_bar.php';
require_once "C:\Projects\gas.station\db\db_person.php";

$persons_obj = new db_person();
$persons = $persons_obj->getPersonAllActive();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Person List</title>
</head>
<body>
    
    <div class="page-title-bar">
        <h3>Person List</h3>
        <a href="index.php?view=person_add" class="add-btn">Add Person</a>
    </div>

    <div class="content">  
    <table class="sys-table">
        <thead>
            <tr>
                <th>Actions</th>
                <th>Full Name</th>
                <th>ID</th>
                <th>Phone</th>
                <th>Email</th>
                <th>dbID</th>      
            </tr>
        </thead>

        <tbody>
        <?php foreach ($persons as $person): ?>
            <tr>
                <td class="actions">
                    <a href="index.php?view=person_view&id=<?= base64_encode($person->per_id) ?>">👁️</a>
                    <a href="index.php?view=person_edit&id=<?= base64_encode($person->per_id) ?>">✏️</a>
                    <a href="index.php?view=person_delete&id=<?= base64_encode($person->per_id) ?>">🗑️</a>
                </td>
                <td><?= $person->full_name ?></td>
                <td><?= $person->per_idnr ?></td>
                <td><?= $person->per_phone ?></td>
                <td><?= $person->per_email ?></td>
                <td><?= $person->per_id ?></td>
        
            </tr>
        <?php endforeach; ?>
        </tbody>

    </table>

</div>
</body>
</html>

