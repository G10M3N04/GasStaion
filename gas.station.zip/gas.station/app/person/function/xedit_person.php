<?php

require_once "C:/Projects/gas.station/db/db_person.php";
include '../root/includes/validation_popup.php';

$per_id = base64_decode($_GET["id"]);

$per_firstname  = $_POST["per_firstname"];
$per_lastname   = $_POST["per_lastname"];
$per_idnr       = $_POST["per_idnr"];
$per_phone      = $_POST["per_phone"];
$per_email      = $_POST["per_email"];
$per_dob        = $_POST["per_dob"];
$per_gender     = $_POST["per_gender"];
$per_ethnicity  = $_POST["per_ethnicity"];

$person_obj = new db_person();
$person = $person_obj->getPersonObjByID($per_id);

$person_obj->value_arr["per_id"] = $per_id;
$person_obj->value_arr["per_firstname"] = $per_firstname;
$person_obj->value_arr["per_lastname"]  = $per_lastname;
$person_obj->value_arr["per_idnr"]      = $per_idnr;
$person_obj->value_arr["per_phone"]     = $per_phone;
$person_obj->value_arr["per_email"]     = $per_email;
$person_obj->value_arr["per_dob"]       = $per_dob;
$person_obj->value_arr["per_gender"]    = $per_gender;
$person_obj->value_arr["per_ethnicity"] = $per_ethnicity;
$person_obj->value_arr["per_is_active"] = "1";

$person_obj->update($person_obj);

    $id = base64_decode($per_id);


    // $msg = 'Login successfully';
    echo "
    <form id='go' action='http://gas.station:8081/?view=backend_person&id=$id' method='post'>
        <input type='hidden' name='popup_msg' value=''>
    </form>
    <script>document.getElementById('go').submit();</script>
    ";
    // popup($msg);

// header("Location: index.php?view=backend_person&id=".base64_encode($per_id))

?>
