<?php

require_once "C:/Projects/gas.station/db/db_person.php";
include '../root/includes/validation_popup.php';

$per_id = base64_decode($_GET["id"]);

$person_obj = new db_person();
$person_obj->set_default();
$person_obj->value_arr["per_id"] = $per_id;

$person_obj->delete($person_obj);

    $id = base64_decode($per_id);
    // $msg = 'Login successfully';
    echo "
    <form id='go' action='http://gas.station:8081/?view=backend_person&id=$id' method='post'>
        <input type='hidden' name='popup_msg' value=''>
    </form>
    <script>document.getElementById('go').submit();</script>
    ";
    // popup($msg);

// header("Location: index.php?view=backend_person&id=".base64_encode($per_id))

?>
