<?php

include '../app/assets/header.php';
include '../app/assets/tab_bar.php';
require_once "C:\Projects\gas.station\db\db_product.php";

$per_id = $_GET["id"];

if(isset($_GET['category'])) $category = $_GET['category'] ? $category = $_GET['category'] : $category = "";


$products_obj = new db_product();
if(empty($category)){
    $products = $products_obj->getAllProducts();
}else{
    $products = $products_obj->getAllProductsByCategories($category);
} 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Dashboard Overview</title>
</head>
<div class="page-container">
    <div class="page-title-bar">
        <h3>Inventory List</h3>
        <a href="index.php?view=inventory_add&id=<?= $per_id ?>" class="add-btn">Add Inventory</a>

        <form method="GET" class="filter-form">
        <input type="hidden" name="view" value="backend_inventory">
        <input type="hidden" name="id" value="<?= $per_id ?>">
            <label for="category">Filter by category:</label>
            <select name="category" id="category" onchange="this.form.submit();">
                <option <? if(empty($category)) echo'selected' ?> value="">All Categories</option>
                <option <? if(!empty($category) && $category=='Beverages') echo 'selected' ? 'selected' : ""?> value="Beverages">Beverages</option>
                <option <? if(!empty($category) && $category=='Edible') echo 'selected' ? 'selected' : ""?> value="Edible">Edible</option>
                <option <? if(!empty($category) && $category=='Tobacco') echo 'selected' ? 'selected' : "" ?> value="Tobacco">Tobacco</option>
                <option <? if(!empty($category) && $category=='Hygiene') echo 'selected' ? 'selected' : ""?> value="Hygiene">Hygiene</option>
                <option <? if(!empty($category) && $category=='Groceries') echo 'selected' ? 'selected' : ""?> value="Groceries">Groceries</option>
                <option <? if(!empty($category) && $category=='Carwash') echo 'selected' ? 'selected' : "" ?> value="Carwash">Carwash</option>
            </select>
        </form>
    </div>

    <table class="table-list">
        <thead>
            <tr>
                <th>Action</th>
                <th>Item</th>
                <th>Category</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Is Active</th> 
            </tr>
        </thead>

        <tbody>
        <?php foreach ($products as $product): ?>
            <tr>   
                <td class="actions">
                    <a href="index.php?view=inventory_view&pro_id=<?= base64_encode($product->pro_id) ?>&id=<?= $per_id ?>">👁️</a>
                    <a href="index.php?view=inventory_edit&pro_id=<?= base64_encode($product->pro_id) ?>&id=<?= $per_id ?>">✏️</a>
                    <a href="index.php?view=inventory_delete&pro_id=<?= base64_encode($product->pro_id) ?>&id=<?= $per_id ?>">🗑️</a>
                </td>
                <td><?= $product->pro_name ?></td>
                <td><?= $product->pro_category ?></td>
                <td>R<?= number_format($product->pro_price, 2) ?></td>
                <td><?= $product->pro_quantity ?></td>
                <td>
                    <div class="toggle-container">
                        <input type="checkbox" name="pro_is_active" value="1" <?= $product->pro_is_active == 1 ? 'checked' : '' ?> id="toggleBtn" hidden>
                        <div class="toggle" id="toggleVisual"></div>
                    </div>   
                </td>
                
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
</html>