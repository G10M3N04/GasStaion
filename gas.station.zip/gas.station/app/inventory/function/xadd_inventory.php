<?php

require_once "C:/Projects/gas.station/db/db_product.php";
include '../root/includes/validation_popup.php';

$per_id = $_GET["id"];

$pro_name  = $_POST["pro_name"] ?? '';
$pro_category   = $_POST["pro_category"] ?? '';
$pro_price   = $_POST["pro_price"];
$pro_quantity  = $_POST["pro_quantity"];

$product_obj = new db_product();
$product_obj->set_default();

$product_obj->value_arr["pro_name"] = $pro_name;
$product_obj->value_arr["pro_category"]  = $pro_category;
$product_obj->value_arr["pro_price"]      = $pro_price;
$product_obj->value_arr["pro_quantity"]     = $pro_quantity;
$product_obj->value_arr["pro_is_active"] = 1;

$product_obj->insert($product_obj);
    // $msg = 'Login successfully';
    echo "
    <form id='go' action='http://gas.station:8081/?view=backend_inventory&id=$per_id' method='post'>
        <input type='hidden' name='popup_msg' value=''>
    </form>
    <script>document.getElementById('go').submit();</script>
    ";
    // popup($msg);

header("Location: index.php?view=backend_inventory&id=$per_id")

?>
