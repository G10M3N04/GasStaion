<?php

require_once "C:/Projects/gas.station/db/db_product.php";
include '../root/includes/validation_popup.php';

$per_id = $_GET["id"];
$pro_id = base64_decode($_GET["pro_id"]);

$product_obj = new db_product();
$product_obj->set_default();
$product_obj->value_arr["pro_id"] = $pro_id;

$product_obj->delete($product_obj);

    // $msg = 'Login successfully';
    echo "
    <form id='go' action='http://gas.station:8081/?view=backend_inventory&id=$per_id' method='post'>
        <input type='hidden' name='popup_msg' value=''>
    </form>
    <script>document.getElementById('go').submit();</script>
    ";
    // popup($msg);

header("Location: index.php?view=backend_inventory&id=$per_id")

?>
