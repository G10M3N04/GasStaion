<?php

include '../root/includes/validation_popup.php';
require_once "C:\Projects\gas.station\db\db_product.php";
require_once "C:\Projects\gas.station\db\db_person.php";

$per_id = base64_decode($_GET["id"]);
$pro_id = base64_decode($_GET["id"]);

$product_obj = new db_product();
$product = $product_obj->getProductObjByID($pro_id);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>View Product</title>
</head>
<body>
    <div class="content">
    <h3>View Product</h3>

    <form method="POST" action="http://gas.station:8081/?view=xedit_inventory&id=<?= base64_encode($pro_id) ?>" class="sys-form">

        <label>Product name</label>
        <input type="text" name="pro_name" value="<?php echo $product->pro_name; ?>" readonly>

        <label>Category</label>
        <input type="text" name="pro_category" value="<?php echo $product->pro_category; ?>" readonly>

        <label>Price</label>
        <input type="text" name="pro_price" value="<?php echo $product->pro_price; ?>" readonly>

        <label>Quantity</label>
        <input type="text" name="pro_quantity" value="<?php echo $product->pro_quantity; ?>" readonly>

        <button type="submit" class="add-btn">Save Product</button>

    </form>
</div>
</body>
</html>