<?php

include '../root/includes/validation_popup.php';
require_once "C:\Projects\gas.station\db\db_product.php";
require_once "C:\Projects\gas.station\db\db_person.php";

$per_id = base64_decode($_GET["id"]);
$pro_id = base64_decode($_GET["pro_id"]);

$product_obj = new db_product();
$product = $product_obj->getProductObjByID($pro_id);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Edit Person</title>
</head>
<body>
    <div class="content">
    <h3>Edit Product</h3>

    <form method="POST" action="http://gas.station:8081/?view=xedit_inventory&pro_id=<?= base64_encode($pro_id) ?>&id=<?= base64_encode($per_id) ?>" class="sys-form">

        <label>Product name</label>
        <input type="text" name="pro_name" value="<?php echo $product->pro_name; ?>" required>

        <label class="category-box" >Select Category:</label>
            <select name="category" required>
                <option value="">-- Choose Category --</option>
                <option value="Beverages">Beverages</option>
                <option value="Edible">Edible</option>
                <option value="Groceries">Groceries</option>
                <option value="Hygiene">Hygiene</option>
                <option value="Tobacco">Tobacco</option>
                <option value="Carwash">Carwash</option>
            </select>

        <label>Price</label>
        <input type="text" name="pro_price" value="<?php echo $product->pro_price; ?>" required>

        <label>Quantity</label>
        <input type="text" name="pro_quantity" value="<?php echo $product->pro_quantity; ?>" required>

        <button type="submit" class="add-btn">Save Product</button>

    </form>
</div>
</body>
</html>