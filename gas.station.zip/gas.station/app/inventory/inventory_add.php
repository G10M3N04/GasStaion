<?php

include '../root/includes/validation_popup.php';
$per_id = $_GET["id"];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Add Inventory</title>
</head>
<body>
    <div class="content">
    <h3>Add Inventory</h3>

    <form method="POST" action="index.php?view=xadd_inventory&id=<?= $per_id?>" class="sys-form">

        <label>Product Name</label>
        <input type="text" name="pro_name" required>

        <label class="category-box" >Select Category:</label>
            <select name="category" required>
                <option value="">-- Choose Category --</option>
                <option value="Beverages">Beverages</option>
                <option value="Edible">Edible</option>
                <option value="Groceries">Groceries</option>
                <option value="Hygiene">Hygiene</option>
                <option value="Tobacco">Tobacco</option>
                <option value="Carwash">Carwash</option>
            </select>

        <label>Product Price</label>
        <input type="number" name="pro_price" required>

        <label>Product Quantity</label>
        <input type="number" name="pro_quantity" required>

        <button type="submit" class="add-btn">Save Product</button>

    </form>
</div>
</body>
</html>