<?php

include '../app/assets/header.php';
include '../app/assets/tab_bar.php';
require_once __DIR__ . '/../../db/connection.php';

$currentYear = date('Y');
$currentMonth = date('n');
$monthlyData = [];

try {
    $conn = db_connection::connection();
    $sql = "
        SELECT CONVERT(date, tns_date) AS day,
               SUM(tns_amount) AS total_amount,
               COUNT(*) AS transaction_count
        FROM transactions
        WHERE YEAR(CONVERT(date, tns_date)) = :year
          AND MONTH(CONVERT(date, tns_date)) = :month
        GROUP BY CONVERT(date, tns_date)
        ORDER BY day
    ";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':year' => $currentYear, ':month' => $currentMonth]);
    $monthlyData = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $monthlyData = [];
}

$totalSales = array_sum(array_column($monthlyData, 'total_amount'));
$totalTransactions = array_sum(array_column($monthlyData, 'transaction_count'));
$daysWithSales = count($monthlyData);
$averageDaily = $daysWithSales ? $totalSales / $daysWithSales : 0;
$topDay = null;
$maxDaySales = 0;
foreach ($monthlyData as $row) {
    if ($row['total_amount'] > $maxDaySales) {
        $maxDaySales = $row['total_amount'];
        $topDay = $row;
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Dashboard Overview</title>
</head>
<body>
    <div class="monthly-dashboard">
        <h1>Monthly Sales Statistics - <?= date('F Y') ?></h1>
        <div class="summary-cards">
            <div class="summary-card">
                <h2>Total sales this month</h2>
                <p>R<?= number_format($totalSales, 2) ?></p>
            </div>
            <div class="summary-card">
                <h2>Days with sales</h2>
                <p><?= $daysWithSales ?></p>
            </div>
            <div class="summary-card">
                <h2>Average daily sales</h2>
                <p>R<?= number_format($averageDaily, 2) ?></p>
            </div>
            <div class="summary-card">
                <h2>Total transactions</h2>
                <p><?= $totalTransactions ?></p>
            </div>
        </div>

        <section class="sales-panel">
            <h2>Sales by day</h2>
            <?php if (!empty($monthlyData)): ?>
                <div class="sales-chart">
                    <?php foreach ($monthlyData as $row): ?>
                        <?php
                            $label = date('j M', strtotime($row['day']));
                            $barHeight = $maxDaySales > 0 ? max(8, round(($row['total_amount'] / $maxDaySales) * 100)) : 8;
                        ?>
                        <div class="sales-bar">
                            <div class="sales-bar-inner" style="height: <?= $barHeight ?>%;">
                                <span>R<?= number_format($row['total_amount'], 0) ?></span>
                            </div>
                            <div class="sales-bar-label"><?= $label ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-message">No recorded sales for <?= date('F Y') ?> yet.</div>
            <?php endif; ?>
        </section>
    </div>
</body>
</html>