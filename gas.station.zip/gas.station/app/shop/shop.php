<?php

include '../app/assets/header.php';
include '../app/assets/tab_bar.php';
require_once "C:\Projects\gas.station\db\db_product.php";

$products_obj = new db_product();
$products = $products_obj->getAllProducts();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Dashboard Overview</title>
</head>
<body>
<div class="page-container">
    <h1>Shop List</h1>

    <table class="table-list">
        <thead>
            <tr>
                <th>Action</th>
                <th>Product</th>
                <th>Category</th>
                <th>Selling Price</th>
                <th>Quantity</th>
            </tr>
        </thead>

        <tbody>
        <?php foreach ($products as $product): 
            if ($product->pro_category == 'Edible') continue;
            ?>
            <tr>
                <td class="actions">
                    <a href="index.php?view=shop_view&id=<?= base64_encode($person->per_id) ?>">👁️</a>
                    <a href="index.php?view=shop_edit&id=<?= base64_encode($person->per_id) ?>">✏️</a>
                    <a href="index.php?view=shop_delete&id=<?= base64_encode($person->per_id) ?>">🗑️</a>
                </td>
                <td><?= $product->pro_name ?></td>
                <td><?= $product->pro_category ?></td>
                <td>R<?= number_format($product->pro_price, 2, ",") ?></td>
                <td><?= $product->pro_quantity ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

</body>
</html>