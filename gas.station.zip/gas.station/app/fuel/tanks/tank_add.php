<?php

include '../root/includes/validation_popup.php';
$per_id = $_GET['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Add Fuel</title>
</head>
<body>
    <div class="content">
    <h3>Add A Tank</h3>

    <form method="POST" action="index.php?view=xadd_tank&id=<?=$per_id ?>" class="sys-form">
        <label for="fuel-type">Select Fuel Type:</label>
            <select name="tnk_type" required>
                <option value="">-- Choose Fuel Type --</option>
                <option value="Diesel">Diesel</option>
                <option value="Unleaded">Unleaded</option>
            </select>

        <label>Fuel Volume</label>
        <input type="number" name="tnk_fuel_volume" required>

        <button type="submit" class="add-btn">Save Tank</button>

    </form>
</div>
</body>
</html>