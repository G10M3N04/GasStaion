<?php

require_once "C:/Projects/gas.station/db/db_tank.php";
include '../root/includes/validation_popup.php';

$per_id = $_GET['id'];
$tnk_id = base64_decode($_GET["tnk_id"]);

$tnk_type = $_POST["tnk_type"];
$tnk_fuel_volume = $_POST["tnk_fuel_volume"];

$tank_obj = new db_tank();
$tank_obj->set_default();

$tank_obj->value_arr["tnk_id"] = $tnk_id;
$tank_obj->value_arr["tnk_type"] = $tnk_type;
$tank_obj->value_arr["tnk_fuel_volume"] = $tnk_fuel_volume;
$tank_obj->value_arr["tnk_is_active"] = 1;

$tank_obj->update($tank_obj);

    // $msg = 'Login successfully';
    echo "
    <form id='go' action='http://gas.station:8081/?view=backend_fuel&tab=tanks&id=$per_id' method='post'>
        <input type='hidden' name='popup_msg' value=''>
    </form>
    <script>document.getElementById('go').submit();</script>
    ";
    // popup($msg);

header("Location: index.php?view=backend_fuel&tab=tanks&id=$per_id")

?>
