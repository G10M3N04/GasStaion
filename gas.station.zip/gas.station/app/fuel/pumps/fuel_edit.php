<?php

require_once "C:/Projects/gas.station/db/db_fuel_pump.php";
require_once "C:/Projects/gas.station/db/db_fuel_readings.php";
include '../root/includes/validation_popup.php';

$per_id = $_GET['id'];
$flp_id = base64_decode($_GET["flp_id"]);

$fuel_obj = new db_fuel_pump();
$fuel = $fuel_obj->getFuelPumpObjByID($flp_id);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Add Fuel</title>
</head>
<body>
    <div class="content">
    <h3>Edit Fuel</h3>

    <form method="POST" action="index.php?view=xedit_fuel&flp_id=<?= $flp_id ?>&id=<?= $per_id ?>" class="sys-form">

        <label>Pump Number</label>
        <input type="number" name="flp_pump_num" value="<?php echo $fuel->flp_pump_num; ?>" required>

        <label class="fuel-box" >Select Fuel Type:</label>
            <select type="text" name="flp_fuel_type" required>
                <option value="">-- Choose Fuel Type --</option>
                <option value="Diesel">Diesel</option>
                <option value="Unleaded">Unleaded</option>
            </select>

        <label>Price/Litre</label>
        <input type="number" name="flp_price_per_litre" value="<?php echo $fuel->flp_price_per_litre; ?>" required>

        <button type="submit" class="add-btn">Save Fuel</button>

    </form>
</div>
</body>
</html>