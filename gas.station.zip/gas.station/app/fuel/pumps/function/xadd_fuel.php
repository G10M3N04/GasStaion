<?php

require_once "C:/Projects/gas.station/db/db_fuel_pump.php";
require_once "C:/Projects/gas.station/db/db_fuel_readings.php";
include '../root/includes/validation_popup.php';

$per_id = $_GET["id"];

$flp_ref_tank = $_POST["flp_ref_tank"];
$flp_pump_num = $_POST["flp_pump_num"];
$flp_fuel_type = $_POST["flp_fuel_type"];
$flp_price_per_litre = $_POST["flp_price_per_litre"];

$fuel_pump_obj = new db_fuel_pump();
$fuel_pump_obj->set_default();

$fuel_pump_obj->value_arr["flp_ref_tank"] = $flp_ref_tank;
$fuel_pump_obj->value_arr["flp_pump_num"] = $flp_pump_num;
$fuel_pump_obj->value_arr["flp_fuel_type"] = $flp_fuel_type;
$fuel_pump_obj->value_arr["flp_price_per_litre"] = $flp_price_per_litre;
$fuel_pump_obj->value_arr["flp_is_active"] = 1;

$fuel_pump_obj->insert($fuel_pump_obj);
    // $msg = 'Login successfully';
    echo "
    <form id='go' action='http://gas.station:8081/?view=backend_fuel&id=$per_id' method='post'>
        <input type='hidden' name='popup_msg' value=''>
    </form>
    <script>document.getElementById('go').submit();</script>
    ";
    // popup($msg);

header("Location: index.php?view=backend_fuel&id=$per_id")
?>
