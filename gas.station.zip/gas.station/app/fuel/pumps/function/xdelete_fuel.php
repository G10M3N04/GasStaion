<?php

require_once "C:/Projects/gas.station/db/db_fuel_pump.php";
require_once "C:/Projects/gas.station/db/db_fuel_readings.php";
include '../root/includes/validation_popup.php';

$per_id = $_GET["id"];
$flp_id = base64_decode($_GET["flp_id"]);

$fuel_obj = new db_fuel_pump();
$fuel_obj->set_default();
$fuel_obj->value_arr["flp_id"] = $flp_id;

$fuel_obj->delete($fuel_obj);
    // $msg = 'Login successfully';
    echo "
    <form id='go' action='http://gas.station:8081/?view=backend_fuel&id=$per_id' method='post'>
        <input type='hidden' name='popup_msg' value=''>
    </form>
    <script>document.getElementById('go').submit();</script>
    ";
    // popup($msg);

header("Location: index.php?view=backend_fuel&id=$per_id")

?>
