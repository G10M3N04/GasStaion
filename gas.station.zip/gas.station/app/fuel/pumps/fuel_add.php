<?php

include '../root/includes/validation_popup.php';
require_once "C:/Projects/gas.station/db/db_tank.php";

$per_id = $_GET['id'];

$tank_obj = new db_tank();
$tanks = $tank_obj->getAllTankObj();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Add Fuel</title>
</head>
<body>
    <div class="content">
    <h3>Add Fuel</h3>

    <form method="POST" action="index.php?view=xadd_fuel&id=<?=$per_id ?>" class="sys-form">

        <label>Pump Number</label>
        <input type="number" name="flp_pump_num" required>

        <label class="fuel-box" >Select Fuel Type:</label>
            <select name="flp_fuel_type" required>
                <option value="">-- Choose Fuel Type --</option>
                <option value="Diesel">Diesel</option>
                <option value="Unleaded">Unleaded</option>
            </select>

        <label class="fuel-box" >Select Tank:</label>
            <select name="flp_ref_tank" required>
                <option value="">-- Choose Tank --</option>
                <?php foreach($tanks as $tank){ ?>
                <option value="<?= $tank->tnk_id ?>">Tank <?= $tank->tnk_id ?></option>
                <?php } ?>
            </select>

        <label>Price/Litre</label>
        <input type="number" name="flp_price_per_litre" required>

        <button type="submit" class="add-btn">Save Fuel</button>

    </form>
</div>
</body>
</html>