<?php
include '../app/assets/header.php';
include '../app/assets/tab_bar.php';

require_once "C:/Projects/gas.station/db/db_fuel_pump.php";
require_once "C:/Projects/gas.station/db/db_fuel_readings.php";
require_once "C:/Projects/gas.station/db/db_tank.php";

$per_id = $_GET['id'];

// Create objects
$tank_obj = new db_tank();
$pump_obj = new db_fuel_pump();
$fuel_obj = new db_fuel_readings();

$tab = $_GET['tab'] ?? 'pumps';

$tanks = $tank_obj->getAllTankObj();
$pumps = $pump_obj->getActivePump();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Fuel Management</title>
</head>

<body>

<div class="page-container">
    <h2>Fuel Tracking</h2>

    <div class="fuel-container">

        <!-- LEFT SIDEBAR -->
        <div class="fuel-sidebar">
            <a href="?view=backend_fuel&tab=pumps&id=<?= $per_id ?>" class="<?= $tab == 'pumps' ? 'active' : '' ?>">Fuel Pumps</a>
            <a href="?view=backend_fuel&tab=tanks&id=<?= $per_id ?>" class="<?= $tab == 'tanks' ? 'active' : '' ?>">Tanks</a>
        </div>

        <!-- RIGHT CONTENT -->
        <div class="fuel-content">

        <?php if ($tab == "pumps"): ?>
            <h3>Fuel Pumps</h3>
            <a href="index.php?view=fuel_add&id=<?= $per_id ?>" class="add-btn">Add Fuel</a>
            <table>

                    <tr>
                        <th>Actions</th>
                        <th>Pump Number</th>
                        <th>Fuel Type</th>
                        <th>Price/Litre</th>
                        <th>Status</th>
                        <th>Is Active</th>
                    </tr>


                    <?php foreach ($pumps as $pump): ?>
                    <tr>
                        <td class="actions">
                            <a href="index.php?view=fuel_edit&flp_id=<?= base64_encode($pump->flp_id) ?>&id=<?= $per_id ?>">✏️</a>
                            <a href="index.php?view=fuel_delete&flp_id=<?= base64_encode($pump->flp_id) ?>&id=<?= $per_id ?>">🗑️</a>
                        </td>
                        <td><?= $pump->flp_pump_num ?></td>
                        <td><?= $pump->flp_fuel_type ?></td>
                        <td>R<?= number_format($pump->flp_price_per_litre, 2) ?></td>
                        <td><?= $pump->flp_is_active ? "Active" : "Inactive" ?></td>
                        <td>
                            <div class="toggle-container">
                                <input type="checkbox" name="flp_is_active" value="1" <?= $pump->flp_is_active == 1 ? 'checked' : '' ?> id="toggleBtn" hidden>
                                <div class="toggle" id="toggleVisual"></div>
                            </div>   
                        </td>
                        
                    </tr>
                    <?php endforeach; ?>
            </table>

        <?php else: ?>
        
            <h3>Tanks</h3>
            <a href="index.php?view=tank_add&id=<?= $per_id  ?>" class="add-btn">Add Tank</a>
            <table>
                <thead>
                    <tr>
                        <th>Actions</th>
                        <th>Tank Type</th>
                        <th>Fuel Volume</th>
                        <!-- <th>Person</th>
                        <th>Manager</th> -->
                        <th>Is Active</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tanks as $tank): ?>
                    <tr>
                        <td class="actions">
                            <a href="index.php?view=tank_edit&tnk_id=<?= base64_encode($tank->tnk_id) ?>&id=<?= $per_id ?>">✏️</a>
                            <a href="index.php?view=tank_delete&tnk_id=<?= base64_encode($tank->tnk_id) ?>&id=<?= $per_id ?>">🗑️</a>
                        </td>
                        <td><?= $tank->tnk_type ?></td>
                        <td><?= $tank->tnk_fuel_volume ?> L</td>
                        <!-- <td><= $tank->tnk_ref_person ?></td>
                        <td><= $tank->tnk_ref_manager ?></td> -->
                        <td>
                            <div class="toggle-container">
                                <input type="checkbox" name="flp_is_active" value="1" <?= $tank->tnk_is_active == 1 ? 'checked' : '' ?> id="toggleActiveBtn" hidden>
                                <div class="toggle" id="toggleVisual"></div>

                            </div>   
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

        <?php endif; ?>

        </div>

    </div>
</div>

</body>
<script>
//     $("#toggleActiveBtn").change(function() {
//     if (this.checked) {
//         console.log("Toggle is ON");
//     } else {
//         console.log("Toggle is OFF");
//     }
// });

</script>
</html>