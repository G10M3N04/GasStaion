<?php

require_once "C:/Projects/gas.station/db/db_cashup.php";
include '../root/includes/validation_popup.php';

$per_id = $_GET["id"];
$cap_id = base64_decode($_GET["cap_id"]);

$cashup_obj = new db_cashup();
$cashup_obj->set_default();
$cashup_obj->value_arr["cap_id"] = $cap_id;

$cashup_obj->delete($cashup_obj);

    echo "
    <form id='go' action='http://gas.station:8081/?view=backend_cashup&id=$per_id' method='post'>
        <input type='hidden' name='popup_msg' value=''>
    </form>
    <script>document.getElementById('go').submit();</script>
    ";
    // popup($msg);

header("Location: index.php?view=backend_cashup&id=$per_id")


?>
