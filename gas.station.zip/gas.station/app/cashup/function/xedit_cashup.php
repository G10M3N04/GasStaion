<?php

require_once "C:/Projects/gas.station/db/db_cashup.php";
require_once "C:/Projects/gas.station/db/db_person.php";
include '../root/includes/validation_popup.php';

$per_id = $_GET["id"];
$cap_id = base64_decode($_GET["cap_id"]);

$cap_opening_amount = $_POST["cap_opening_amount"];
$cap_closing_amount = $_POST["cap_closing_amount"];
$cap_total_sales = $_POST["cap_total_sales"];
$cap_date = $_POST["cap_date"];

$cashup_obj = new db_cashup();
$cashup = $cashup_obj->getAllCashups();


$cashup_obj->value_arr["cap_id"] = $cap_id;
$cashup_obj->value_arr["cap_opening_amount"] = $cap_opening_amount;
$cashup_obj->value_arr["cap_closing_amount"] = $cap_closing_amount;
$cashup_obj->value_arr["cap_total_sales"] = $cap_total_sales;
$cashup_obj->value_arr["cap_date"] = $cap_date;

$cashup_obj->update($cashup_obj);

    echo "
    <form id='go' action='http://gas.station:8081/?view=backend_cashup&id=$per_id' method='post'>
        <input type='hidden' name='popup_msg' value=''>
    </form>
    <script>document.getElementById('go').submit();</script>
    ";
    // popup($msg);

header("Location: index.php?view=backend_cashup&id=$per_id")


?>
