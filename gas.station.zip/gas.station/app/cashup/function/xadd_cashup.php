<?php

require_once "C:/Projects/gas.station/db/db_cashup.php";
include '../root/includes/validation_popup.php';

$per_id = $_GET["id"];

// $cap_ref_person  = $_POST["cap_ref_person"];
$cap_opening_amount   = $_POST["cap_opening_amount"];
$cap_closing_amount   = $_POST["cap_closing_amount"];
$cap_total_sales  = $_POST["cap_total_sales"];
$cap_date  = $_POST["cap_date"];
$cap_is_active = $_POST["cap_is_active"];

$cashup_obj = new db_cashup();
$cashup_obj->set_default();

// $cashup_obj->value_arr["cap_ref_person"] = $cap_ref_person;
$cashup_obj->value_arr["cap_opening_amount"] = $cap_opening_amount;
$cashup_obj->value_arr["cap_closing_amount"] = $cap_closing_amount;
$cashup_obj->value_arr["cap_total_sales"] = $cap_total_sales;
$cashup_obj->value_arr["cap_date"] = $cap_date;
$cashup_obj->value_arr["cap_is_active"] = 1;

$cashup_obj->insert($cashup_obj);

    // $msg = 'Login successfully';
    echo "
    <form id='go' action='http://gas.station:8081/?view=backend_cashup&id=$per_id' method='post'>
        <input type='hidden' name='popup_msg' value=''>
    </form>
    <script>document.getElementById('go').submit();</script>
    ";
    // popup($msg);

header("Location: index.php?view=backend_cashup&id=$per_id")

?>
