<?php 

$per_id = $_GET["id"];
print_r($per_id);


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Cashup</title>
</head>
<body>
    <h2>Add Cashup</h2>

<form method="POST" action="index.php?view=xadd_cashup&id=<?= $per_id?>" class="sys-form">

        <label>Opening Sales</label>
        <input type="text" name="cap_opening_amount" required>

        <label>Closing Sales</label>
        <input type="text" name="cap_closing_amount" required>

        <label>Total Sales</label>
        <input type="number" name="cap_total_sales" required>

        <label>Date</label>
        <input type="date" name="cap_date" required>

        <button type="submit" class="add-btn">Save</button>

    </form>
</body>
</html>