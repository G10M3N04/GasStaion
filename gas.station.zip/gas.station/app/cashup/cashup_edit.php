<?php

include '../root/includes/validation_popup.php';
require_once "C:\Projects\gas.station\db\db_cashup.php";
require_once "C:\Projects\gas.station\db\db_person.php";

$per_id = $_GET["id"];
$cap_id = base64_decode($_GET["cap_id"]);

$cashup_obj = new db_cashup();
$cashup = $cashup_obj->getCashupObjByID($cap_id);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Edit Person</title>
</head>
<body>
    <div class="content">
    <h3>Change Cashup</h3>

    <form method="POST" action="http://gas.station:8081/?view=xedit_cashup&cap_id=<?= $cap_id ?>&id=<?= $per_id ?>" class="sys-form">

        <label>Opening Amount</label>
        <input type="number" name="cap_opening_amount" value="<?php echo $cashup->cap_opening_amount; ?>" required>

        <label>Closing Amount</label>
        <input type="number" name="cap_closing_amount" value="<?php echo $cashup->cap_closing_amount; ?>" required>

        <label>Total Sales</label>
        <input type="number" name="cap_total_sales" value="<?php echo $cashup->cap_total_sales; ?>" required>

        <label>Date</label>
        <input type="date" name="cap_date" value="<?php echo $cashup->cap_date; ?>" required>

        <button type="submit" class="add-btn">Save</button>

    </form>
</div>
</body>
</html>