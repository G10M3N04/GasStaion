<?php

include '../app/assets/header.php';
include '../app/assets/tab_bar.php';
require_once "C:\Projects\gas.station\db\db_cashup.php";

$per_id = $_GET["id"];

$cashups_obj = new db_cashup();
$cashups = $cashups_obj->getAllCashups();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Cashups</title>
</head>
<div class="page-container">
    <div class="page-title-bar">
        <h3>Cashup </h3>
        <a href="index.php?view=cashup_add&id=<?= $per_id ?>" class="add-btn">Add Cashup</a>

        <form method="GET">
        <input type="hidden" name="view" value="backend_inventory">
        <input type="hidden" name="id" value="<?= $_GET['id'] ?>">
        </form>
    </div>

    <table class="table-list">
        <thead>
            <tr>
                <th>Action</th>
                <th>Opening</th>
                <th>Closing</th>
                <th>Total Sales</th>
                <th>Date</th> 
            </tr>
        </thead>

        <tbody>
        <?php foreach ($cashups as $cashup): ?>
            <tr>   
                <td class="actions">
                    <a href="index.php?view=cashup_edit&cap_id=<?= base64_encode($cashup->cap_id) ?>&id=<?= $per_id ?>">✏️</a>
                    <a href="index.php?view=cashup_delete&cap_id=<?= base64_encode($cashup->cap_id) ?>&id=<?= $per_id ?>">🗑️</a>
                </td>
                <td>R<?= number_format($cashup->cap_opening_amount, 2) ?></td>
                <td>R<?= number_format($cashup->cap_closing_amount, 2) ?></td>
                <td>R<?= number_format($cashup->cap_total_sales, 2) ?></td>
                <td><?= $cashup->cap_date ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
</html>