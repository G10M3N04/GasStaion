<?php
// vendor\bin\phpunit tests\dbfuelpumpTest.php

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../db/connection.php';
require_once __DIR__ . '/../db/db_base.php';
require_once __DIR__ . '/../db/db_fuel_pump.php';

use PHPUnit\Framework\TestCase;

class DbFuelPumpTest extends TestCase
{
    // ----------------------------------------------------------------
    // Helpers
    // ----------------------------------------------------------------

    private function injectPdo(PDO $pdo): void
    {
        $ref = new ReflectionProperty(db_connection::class, 'conn');
        $ref->setValue(null, $pdo);
    }

    private function resetConnection(): void
    {
        $ref = new ReflectionProperty(db_connection::class, 'conn');
        $ref->setValue(null, false);
    }

    protected function setUp(): void    { $this->resetConnection(); }
    protected function tearDown(): void { $this->resetConnection(); }

    /**
     * Build a mock PDOStatement with controllable fetch/fetchAll returns.
     */
    private function mockStmt(mixed $fetchResult = null, array $fetchAllResult = []): PDOStatement
    {
        $stmt = $this->createMock(PDOStatement::class);
        $stmt->method('execute')->willReturn(true);
        $stmt->method('fetch')->willReturn($fetchResult);
        $stmt->method('fetchAll')->willReturn($fetchAllResult);
        return $stmt;
    }

    /**
     * Build a mock PDO that returns $stmt from prepare().
     */
    private function mockPdo(PDOStatement $stmt): PDO
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willReturn($stmt);
        $pdo->method('setAttribute')->willReturn(true);
        return $pdo;
    }

    /**
     * Build a mock PDO that captures the SQL passed to prepare().
     */
    private function mockPdoCapturingSql(PDOStatement $stmt, string &$capturedSql): PDO
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('setAttribute')->willReturn(true);
        $pdo->method('prepare')->willReturnCallback(
            function (string $sql) use ($stmt, &$capturedSql) {
                $capturedSql = $sql;
                return $stmt;
            }
        );
        return $pdo;
    }

    /**
     * Build a sample fuel pump object the way the DB would return one.
     */
    private function makePump(int $id = 1, int $isActive = 1): object
    {
        return (object)[
            'flp_id'             => $id,
            'flp_ref_tank'       => 10,
            'flp_pump_num'       => $id,
            'flp_fuel_type'      => 'diesel',
            'flp_price_per_litre'=> 22.50,
            'flp_is_active'      => $isActive,
        ];
    }

    // ----------------------------------------------------------------
    // Class structure
    // ----------------------------------------------------------------

    public function testTablePropertyIsFuelPump(): void
    {
        $this->assertSame('fuel_pump', (new db_fuel_pump())->table);
    }

    public function testFieldArrHasSixFields(): void
    {
        $this->assertCount(6, (new db_fuel_pump())->field_arr);
    }

    public function testValueArrStartsEmpty(): void
    {
        $this->assertSame([], (new db_fuel_pump())->value_arr);
    }

    // ----------------------------------------------------------------
    // set_default()
    // ----------------------------------------------------------------

    public function testSetDefaultPopulatesAllKeys(): void
    {
        $p = new db_fuel_pump();
        $p->set_default();

        $this->assertArrayHasKey('flp_id',              $p->value_arr);
        $this->assertArrayHasKey('flp_ref_tank',        $p->value_arr);
        $this->assertArrayHasKey('flp_pump_num',        $p->value_arr);
        $this->assertArrayHasKey('flp_fuel_type',       $p->value_arr);
        $this->assertArrayHasKey('flp_price_per_litre', $p->value_arr);
        $this->assertArrayHasKey('flp_is_active',       $p->value_arr);
    }

    public function testSetDefaultSetsEmptyStringDefaults(): void
    {
        $p = new db_fuel_pump();
        $p->set_default();

        foreach ($p->value_arr as $key => $value) {
            $this->assertSame('', $value, "Expected empty default for '$key'");
        }
    }

    public function testSetDefaultCountMatchesFieldArr(): void
    {
        $p = new db_fuel_pump();
        $p->set_default();

        $this->assertCount(count($p->field_arr), $p->value_arr);
    }

    // ----------------------------------------------------------------
    // getPumpByTank()
    // ----------------------------------------------------------------

    public function testGetPumpByTankReturnsArray(): void
    {
        $rows = [$this->makePump(1), $this->makePump(2)];
        $this->injectPdo($this->mockPdo($this->mockStmt(null, $rows)));

        $result = (new db_fuel_pump())->getPumpByTank();

        $this->assertIsArray($result);
        $this->assertCount(2, $result);
    }

    public function testGetPumpByTankReturnsEmptyArrayWhenNone(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(null, [])));

        $result = (new db_fuel_pump())->getPumpByTank();

        $this->assertIsArray($result);
        $this->assertEmpty($result);
    }

    public function testGetPumpByTankSqlContainsLeftJoinOnTank(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(null, []), $capturedSql);
        $this->injectPdo($pdo);

        (new db_fuel_pump())->getPumpByTank();

        $this->assertStringContainsString('LEFT JOIN', $capturedSql);
        $this->assertStringContainsString('tank', $capturedSql);
    }

    public function testGetPumpByTankReturnsObjects(): void
    {
        $rows = [$this->makePump(1)];
        $this->injectPdo($this->mockPdo($this->mockStmt(null, $rows)));

        $result = (new db_fuel_pump())->getPumpByTank();

        $this->assertIsObject($result[0]);
        $this->assertSame(1, $result[0]->flp_id);
    }

    // ----------------------------------------------------------------
    // getAllFuelPumpObj()
    // ----------------------------------------------------------------

    public function testGetAllFuelPumpObjReturnsArray(): void
    {
        $rows = [$this->makePump(1), $this->makePump(2), $this->makePump(3)];
        $this->injectPdo($this->mockPdo($this->mockStmt(null, $rows)));

        $result = (new db_fuel_pump())->getAllFuelPumpObj();

        $this->assertIsArray($result);
        $this->assertCount(3, $result);
    }

    public function testGetAllFuelPumpObjReturnsEmptyArrayWhenNone(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(null, [])));

        $result = (new db_fuel_pump())->getAllFuelPumpObj();

        $this->assertIsArray($result);
        $this->assertEmpty($result);
    }

    public function testGetAllFuelPumpObjSqlSelectsFromFuelPump(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(null, []), $capturedSql);
        $this->injectPdo($pdo);

        (new db_fuel_pump())->getAllFuelPumpObj();

        $this->assertStringContainsString('fuel_pump', $capturedSql);
    }

    public function testGetAllFuelPumpObjReturnsObjectsWithCorrectFields(): void
    {
        $rows = [$this->makePump(4)];
        $this->injectPdo($this->mockPdo($this->mockStmt(null, $rows)));

        $result = (new db_fuel_pump())->getAllFuelPumpObj();

        $this->assertSame(4,        $result[0]->flp_id);
        $this->assertSame('diesel', $result[0]->flp_fuel_type);
        $this->assertSame(22.50,    $result[0]->flp_price_per_litre);
    }

    // ----------------------------------------------------------------
    // getActivePump()
    // ----------------------------------------------------------------

    public function testGetActivePumpReturnsOnlyActiveRows(): void
    {
        $rows = [$this->makePump(1, 1), $this->makePump(2, 1)];
        $this->injectPdo($this->mockPdo($this->mockStmt(null, $rows)));

        $result = (new db_fuel_pump())->getActivePump();

        $this->assertIsArray($result);
        $this->assertCount(2, $result);
        foreach ($result as $pump) {
            $this->assertSame(1, $pump->flp_is_active);
        }
    }

    public function testGetActivePumpReturnsEmptyArrayWhenNoneActive(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(null, [])));

        $result = (new db_fuel_pump())->getActivePump();

        $this->assertIsArray($result);
        $this->assertEmpty($result);
    }

    public function testGetActivePumpSqlFiltersOnIsActive(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(null, []), $capturedSql);
        $this->injectPdo($pdo);

        (new db_fuel_pump())->getActivePump();

        $this->assertStringContainsString('flp_is_active', $capturedSql);
        $this->assertStringContainsString('1', $capturedSql);
    }

    // ----------------------------------------------------------------
    // getJoinedPumpAndReadings()
    // ----------------------------------------------------------------

    public function testGetJoinedPumpAndReadingsReturnsArray(): void
    {
        $rows = [$this->makePump(1), $this->makePump(2)];
        $this->injectPdo($this->mockPdo($this->mockStmt(null, $rows)));

        $result = (new db_fuel_pump())->getJoinedPumpAndReadings();

        $this->assertIsArray($result);
        $this->assertCount(2, $result);
    }

    public function testGetJoinedPumpAndReadingsReturnsEmptyArrayWhenNone(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(null, [])));

        $result = (new db_fuel_pump())->getJoinedPumpAndReadings();

        $this->assertIsArray($result);
        $this->assertEmpty($result);
    }

    public function testGetJoinedPumpAndReadingsSqlJoinsFuelReadings(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(null, []), $capturedSql);
        $this->injectPdo($pdo);

        (new db_fuel_pump())->getJoinedPumpAndReadings();

        $this->assertStringContainsString('LEFT JOIN', $capturedSql);
        $this->assertStringContainsString('fuel_readings', $capturedSql);
    }

    public function testGetJoinedPumpAndReadingsSqlJoinsOnCorrectKey(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(null, []), $capturedSql);
        $this->injectPdo($pdo);

        (new db_fuel_pump())->getJoinedPumpAndReadings();

        $this->assertStringContainsString('flp_id', $capturedSql);
        $this->assertStringContainsString('flr_ref_fuel_pump', $capturedSql);
    }

    // ----------------------------------------------------------------
    // getFuelPumpObjByID()
    // ----------------------------------------------------------------

    public function testGetFuelPumpObjByIDReturnsObjectWhenFound(): void
    {
        $row = $this->makePump(7);
        $this->injectPdo($this->mockPdo($this->mockStmt($row)));

        $result = (new db_fuel_pump())->getFuelPumpObjByID(7);

        $this->assertIsObject($result);
        $this->assertSame(7, $result->flp_id);
    }

    public function testGetFuelPumpObjByIDReturnsCorrectFields(): void
    {
        $row = $this->makePump(3);
        $this->injectPdo($this->mockPdo($this->mockStmt($row)));

        $result = (new db_fuel_pump())->getFuelPumpObjByID(3);

        $this->assertSame('diesel', $result->flp_fuel_type);
        $this->assertSame(22.50,    $result->flp_price_per_litre);
        $this->assertSame(10,       $result->flp_ref_tank);
    }

    public function testGetFuelPumpObjByIDReturnsFalseWhenNotFound(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(false)));

        $result = (new db_fuel_pump())->getFuelPumpObjByID(9999);

        $this->assertFalse($result);
    }

    public function testGetFuelPumpObjByIDReturnsFalseOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('DB error'));
        $this->injectPdo($pdo);

        ob_start();
        $result = (new db_fuel_pump())->getFuelPumpObjByID(1);
        ob_end_clean();

        $this->assertFalse($result);
    }

    public function testGetFuelPumpObjByIDOutputsErrorOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('connection lost'));
        $this->injectPdo($pdo);

        ob_start();
        (new db_fuel_pump())->getFuelPumpObjByID(1);
        $output = ob_get_clean();

        $this->assertStringContainsString('Validation error:', $output);
    }

    public function testGetFuelPumpObjByIDSqlContainsFlpId(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(false), $capturedSql);
        $this->injectPdo($pdo);

        (new db_fuel_pump())->getFuelPumpObjByID(1);

        $this->assertStringContainsString('flp_id', $capturedSql);
    }

    // ----------------------------------------------------------------
    // getJoinedTanksAndPump()
    // ----------------------------------------------------------------

    public function testGetJoinedTanksAndPumpReturnsArray(): void
    {
        $rows = [$this->makePump(1), $this->makePump(2)];
        $this->injectPdo($this->mockPdo($this->mockStmt(null, $rows)));

        $result = (new db_fuel_pump())->getJoinedTanksAndPump();

        $this->assertIsArray($result);
        $this->assertCount(2, $result);
    }

    public function testGetJoinedTanksAndPumpReturnsEmptyArrayWhenNone(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(null, [])));

        $result = (new db_fuel_pump())->getJoinedTanksAndPump();

        $this->assertIsArray($result);
        $this->assertEmpty($result);
    }

    public function testGetJoinedTanksAndPumpSqlJoinsFuelPumpOnTank(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(null, []), $capturedSql);
        $this->injectPdo($pdo);

        (new db_fuel_pump())->getJoinedTanksAndPump();

        $this->assertStringContainsString('tank', $capturedSql);
        $this->assertStringContainsString('LEFT JOIN', $capturedSql);
        $this->assertStringContainsString('fuel_pump', $capturedSql);
    }

    public function testGetJoinedTanksAndPumpSqlJoinsOnCorrectKey(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(null, []), $capturedSql);
        $this->injectPdo($pdo);

        (new db_fuel_pump())->getJoinedTanksAndPump();

        $this->assertStringContainsString('tnk_id', $capturedSql);
        $this->assertStringContainsString('flp_ref_tank', $capturedSql);
    }
}