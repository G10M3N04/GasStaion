<?php
// vendor\bin\phpunit tests\dbfuelreadingsTest.php

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../db/connection.php';
require_once __DIR__ . '/../db/db_base.php';
require_once __DIR__ . '/../db/db_fuel_readings.php';

use PHPUnit\Framework\TestCase;

class DbFuelReadingsTest extends TestCase
{
    // ----------------------------------------------------------------
    // Helpers
    // ----------------------------------------------------------------

    private function injectPdo(PDO $pdo): void
    {
        $ref = new ReflectionProperty(db_connection::class, 'conn');
        $ref->setValue(null, $pdo);
    }

    private function resetConnection(): void
    {
        $ref = new ReflectionProperty(db_connection::class, 'conn');
        $ref->setValue(null, false);
    }

    protected function setUp(): void    { $this->resetConnection(); }
    protected function tearDown(): void { $this->resetConnection(); }

    private function mockStmt(mixed $fetchResult = null, array $fetchAllResult = []): PDOStatement
    {
        $stmt = $this->createMock(PDOStatement::class);
        $stmt->method('execute')->willReturn(true);
        $stmt->method('fetch')->willReturn($fetchResult);
        $stmt->method('fetchAll')->willReturn($fetchAllResult);
        return $stmt;
    }

    private function mockPdo(PDOStatement $stmt): PDO
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willReturn($stmt);
        $pdo->method('setAttribute')->willReturn(true);
        return $pdo;
    }

    private function mockPdoCapturingSql(PDOStatement $stmt, string &$capturedSql): PDO
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('setAttribute')->willReturn(true);
        $pdo->method('prepare')->willReturnCallback(
            function (string $sql) use ($stmt, &$capturedSql) {
                $capturedSql = $sql;
                return $stmt;
            }
        );
        return $pdo;
    }

    private function makeReading(int $id = 1): object
    {
        return (object)[
            'flr_id'               => $id,
            'flr_ref_fuel_pump'    => 2,
            'flr_ref_shift'        => 3,
            'flr_opening_readings' => 1500.50,
            'flr_closing_readings' => 1750.75,
            'flr_recorded_date'    => '2025-01-15',
        ];
    }

    // ----------------------------------------------------------------
    // Class structure
    // ----------------------------------------------------------------

    public function testTablePropertyIsFuelReadings(): void
    {
        $this->assertSame('fuel_readings', (new db_fuel_readings())->table);
    }

    public function testFieldArrHasSixFields(): void
    {
        $this->assertCount(6, (new db_fuel_readings())->field_arr);
    }

    public function testValueArrStartsEmpty(): void
    {
        $this->assertSame([], (new db_fuel_readings())->value_arr);
    }

    public function testFieldArrContainsExpectedFieldNames(): void
    {
        $fields = array_column((new db_fuel_readings())->field_arr, 'field');

        $this->assertContains('flr_id',               $fields);
        $this->assertContains('flr_ref_fuel_pump',    $fields);
        $this->assertContains('flr_ref_shift',        $fields);
        $this->assertContains('flr_opening_readings', $fields);
        $this->assertContains('flr_closing_readings', $fields);
        $this->assertContains('flr_recorded_date',    $fields);
    }

    // ----------------------------------------------------------------
    // set_default()
    // ----------------------------------------------------------------

    public function testSetDefaultPopulatesAllKeys(): void
    {
        $f = new db_fuel_readings();
        $f->set_default();

        $this->assertArrayHasKey('flr_id',               $f->value_arr);
        $this->assertArrayHasKey('flr_ref_fuel_pump',    $f->value_arr);
        $this->assertArrayHasKey('flr_ref_shift',        $f->value_arr);
        $this->assertArrayHasKey('flr_opening_readings', $f->value_arr);
        $this->assertArrayHasKey('flr_closing_readings', $f->value_arr);
        $this->assertArrayHasKey('flr_recorded_date',    $f->value_arr);
    }

    public function testSetDefaultSetsEmptyStringDefaults(): void
    {
        $f = new db_fuel_readings();
        $f->set_default();

        foreach ($f->value_arr as $key => $value) {
            $this->assertSame('', $value, "Expected empty default for '$key'");
        }
    }

    public function testSetDefaultCountMatchesFieldArr(): void
    {
        $f = new db_fuel_readings();
        $f->set_default();

        $this->assertCount(count($f->field_arr), $f->value_arr);
    }

    // ----------------------------------------------------------------
    // getAllFuelObj()
    // ----------------------------------------------------------------

    public function testGetAllFuelObjReturnsArray(): void
    {
        $rows = [$this->makeReading(1), $this->makeReading(2)];
        $this->injectPdo($this->mockPdo($this->mockStmt(null, $rows)));

        $result = (new db_fuel_readings())->getAllFuelObj();

        $this->assertIsArray($result);
        $this->assertCount(2, $result);
    }

    public function testGetAllFuelObjReturnsEmptyArrayWhenNone(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(null, [])));

        $result = (new db_fuel_readings())->getAllFuelObj();

        $this->assertIsArray($result);
        $this->assertEmpty($result);
    }

    public function testGetAllFuelObjReturnsObjectsWithCorrectFields(): void
    {
        $rows = [$this->makeReading(5)];
        $this->injectPdo($this->mockPdo($this->mockStmt(null, $rows)));

        $result = (new db_fuel_readings())->getAllFuelObj();

        $this->assertIsObject($result[0]);
        $this->assertSame(5,            $result[0]->flr_id);
        $this->assertSame(1500.50,      $result[0]->flr_opening_readings);
        $this->assertSame(1750.75,      $result[0]->flr_closing_readings);
        $this->assertSame('2025-01-15', $result[0]->flr_recorded_date);
    }

    public function testGetAllFuelObjSqlSelectsFromFuelReadings(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(null, []), $capturedSql);
        $this->injectPdo($pdo);

        (new db_fuel_readings())->getAllFuelObj();

        $this->assertStringContainsString('fuel_readings', $capturedSql);
    }

    public function testGetAllFuelObjSqlStartsWithSelect(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(null, []), $capturedSql);
        $this->injectPdo($pdo);

        (new db_fuel_readings())->getAllFuelObj();

        $this->assertStringStartsWith('SELECT', $capturedSql);
    }

    // ----------------------------------------------------------------
    // getFuelReadingsObjByID()
    // ----------------------------------------------------------------

    public function testGetFuelReadingsObjByIDReturnsObjectWhenFound(): void
    {
        $row = $this->makeReading(4);
        $this->injectPdo($this->mockPdo($this->mockStmt($row)));

        $result = (new db_fuel_readings())->getFuelReadingsObjByID(4);

        $this->assertIsObject($result);
        $this->assertSame(4, $result->flr_id);
    }

    public function testGetFuelReadingsObjByIDReturnsCorrectFields(): void
    {
        $row = $this->makeReading(3);
        $this->injectPdo($this->mockPdo($this->mockStmt($row)));

        $result = (new db_fuel_readings())->getFuelReadingsObjByID(3);

        $this->assertSame(2,            $result->flr_ref_fuel_pump);
        $this->assertSame(3,            $result->flr_ref_shift);
        $this->assertSame(1500.50,      $result->flr_opening_readings);
        $this->assertSame(1750.75,      $result->flr_closing_readings);
        $this->assertSame('2025-01-15', $result->flr_recorded_date);
    }

    public function testGetFuelReadingsObjByIDReturnsFalseWhenNotFound(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(false)));

        $result = (new db_fuel_readings())->getFuelReadingsObjByID(9999);

        $this->assertFalse($result);
    }

    public function testGetFuelReadingsObjByIDReturnsFalseOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('DB error'));
        $this->injectPdo($pdo);

        ob_start();
        $result = (new db_fuel_readings())->getFuelReadingsObjByID(1);
        ob_end_clean();

        $this->assertFalse($result);
    }

    public function testGetFuelReadingsObjByIDOutputsErrorOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('connection lost'));
        $this->injectPdo($pdo);

        ob_start();
        (new db_fuel_readings())->getFuelReadingsObjByID(1);
        $output = ob_get_clean();

        $this->assertStringContainsString('Validation error:', $output);
    }

    public function testGetFuelReadingsObjByIDSqlContainsFlrId(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(false), $capturedSql);
        $this->injectPdo($pdo);

        (new db_fuel_readings())->getFuelReadingsObjByID(1);

        $this->assertStringContainsString('flr_id', $capturedSql);
    }

    public function testGetFuelReadingsObjByIDSqlQueriesFuelReadingsTable(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(false), $capturedSql);
        $this->injectPdo($pdo);

        (new db_fuel_readings())->getFuelReadingsObjByID(1);

        $this->assertStringContainsString('fuel_readings', $capturedSql);
    }

    public function testGetFuelReadingsObjByIDSqlUsesWhereClause(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(false), $capturedSql);
        $this->injectPdo($pdo);

        (new db_fuel_readings())->getFuelReadingsObjByID(1);

        $this->assertStringContainsString('WHERE', $capturedSql);
    }
}