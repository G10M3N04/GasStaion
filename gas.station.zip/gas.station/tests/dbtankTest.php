<?php
// vendor\bin\phpunit tests\dbtankTest.php

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../db/connection.php';
require_once __DIR__ . '/../db/db_base.php';
require_once __DIR__ . '/../db/db_tank.php';

use PHPUnit\Framework\TestCase;

class DbTankTest extends TestCase
{
    // ----------------------------------------------------------------
    // Helpers
    // ----------------------------------------------------------------

    private function injectPdo(PDO $pdo): void
    {
        $ref = new ReflectionProperty(db_connection::class, 'conn');
        $ref->setValue(null, $pdo);
    }

    private function resetConnection(): void
    {
        $ref = new ReflectionProperty(db_connection::class, 'conn');
        $ref->setValue(null, false);
    }

    protected function setUp(): void    { $this->resetConnection(); }
    protected function tearDown(): void { $this->resetConnection(); }

    private function mockStmt(mixed $fetchResult = null, array $fetchAllResult = []): PDOStatement
    {
        $stmt = $this->createMock(PDOStatement::class);
        $stmt->method('execute')->willReturn(true);
        $stmt->method('fetch')->willReturn($fetchResult);
        $stmt->method('fetchAll')->willReturn($fetchAllResult);
        return $stmt;
    }

    private function mockPdo(PDOStatement $stmt): PDO
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willReturn($stmt);
        $pdo->method('setAttribute')->willReturn(true);
        return $pdo;
    }

    private function mockPdoCapturingSql(PDOStatement $stmt, string &$capturedSql): PDO
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('setAttribute')->willReturn(true);
        $pdo->method('prepare')->willReturnCallback(
            function (string $sql) use ($stmt, &$capturedSql) {
                $capturedSql = $sql;
                return $stmt;
            }
        );
        return $pdo;
    }

    private function makeTank(int $id = 1, int $isActive = 1): object
    {
        return (object)[
            'tnk_id'          => $id,
            'tnk_ref_person'  => 10,
            'tnk_ref_manager' => 20,
            'tnk_fuel_volume' => 5000.00,
            'tnk_type'        => 'diesel',
            'tnk_is_active'   => $isActive,
        ];
    }

    private function makeTankAssoc(int $id = 1): array
    {
        return [
            'tnk_id'          => $id,
            'tnk_ref_person'  => 10,
            'tnk_ref_manager' => 20,
            'tnk_fuel_volume' => 5000.00,
            'tnk_type'        => 'diesel',
            'tnk_is_active'   => 1,
        ];
    }

    // ----------------------------------------------------------------
    // Class structure
    // ----------------------------------------------------------------

    public function testTablePropertyIsTank(): void
    {
        $this->assertSame('tank', (new db_tank())->table);
    }

    public function testFieldArrHasSixFields(): void
    {
        $this->assertCount(6, (new db_tank())->field_arr);
    }

    public function testValueArrStartsEmpty(): void
    {
        $this->assertSame([], (new db_tank())->value_arr);
    }

    public function testFieldArrContainsExpectedFieldNames(): void
    {
        $fields = array_column((new db_tank())->field_arr, 'field');

        $this->assertContains('tnk_id',          $fields);
        $this->assertContains('tnk_ref_person',  $fields);
        $this->assertContains('tnk_ref_manager', $fields);
        $this->assertContains('tnk_fuel_volume', $fields);
        $this->assertContains('tnk_type',        $fields);
        $this->assertContains('tnk_is_active',   $fields);
    }

    // ----------------------------------------------------------------
    // set_default()
    // ----------------------------------------------------------------

    public function testSetDefaultPopulatesAllKeys(): void
    {
        $t = new db_tank();
        $t->set_default();

        $this->assertArrayHasKey('tnk_id',          $t->value_arr);
        $this->assertArrayHasKey('tnk_ref_person',  $t->value_arr);
        $this->assertArrayHasKey('tnk_ref_manager', $t->value_arr);
        $this->assertArrayHasKey('tnk_fuel_volume', $t->value_arr);
        $this->assertArrayHasKey('tnk_type',        $t->value_arr);
        $this->assertArrayHasKey('tnk_is_active',   $t->value_arr);
    }

    public function testSetDefaultSetsEmptyStringDefaults(): void
    {
        $t = new db_tank();
        $t->set_default();

        foreach ($t->value_arr as $key => $value) {
            $this->assertSame('', $value, "Expected empty default for '$key'");
        }
    }

    public function testSetDefaultCountMatchesFieldArr(): void
    {
        $t = new db_tank();
        $t->set_default();

        $this->assertCount(count($t->field_arr), $t->value_arr);
    }

    // ----------------------------------------------------------------
    // getStatus()
    // ----------------------------------------------------------------

    public function testGetStatusReturnsEmptyAtOrBelow5(): void
    {
        $t = new db_tank();
        $this->assertSame('EMPTY', $t->getStatus(0));
        $this->assertSame('EMPTY', $t->getStatus(5));
    }

    public function testGetStatusReturnsLowBetween6And20(): void
    {
        $t = new db_tank();
        $this->assertSame('LOW', $t->getStatus(6));
        $this->assertSame('LOW', $t->getStatus(20));
    }

    public function testGetStatusReturnsGoodAt50(): void
    {
        $this->assertSame('GOOD', (new db_tank())->getStatus(50));
    }

    public function testGetStatusReturnsPerfectAt90AndAbove(): void
    {
        $t = new db_tank();
        $this->assertSame('PERFECT', $t->getStatus(90));
        $this->assertSame('PERFECT', $t->getStatus(100));
    }

    public function testGetStatusReturnsOkForMiddleValues(): void
    {
        $t = new db_tank();
        $this->assertSame('OK', $t->getStatus(21));
        $this->assertSame('OK', $t->getStatus(49));
        $this->assertSame('OK', $t->getStatus(51));
        $this->assertSame('OK', $t->getStatus(89));
    }

    // ----------------------------------------------------------------
    // getTankById()
    // ----------------------------------------------------------------

    public function testGetTankByIdReturnsAssocArrayWhenFound(): void
    {
        $row = $this->makeTankAssoc(3);
        $this->injectPdo($this->mockPdo($this->mockStmt($row)));

        $result = (new db_tank())->getTankById(3);

        $this->assertIsArray($result);
        $this->assertSame(3,       $result['tnk_id']);
        $this->assertSame('diesel',$result['tnk_type']);
    }

    public function testGetTankByIdReturnsFalseWhenNotFound(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(false)));

        $result = (new db_tank())->getTankById(9999);

        $this->assertFalse($result);
    }

    public function testGetTankByIdSqlContainsTnkId(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(false), $capturedSql);
        $this->injectPdo($pdo);

        (new db_tank())->getTankById(1);

        $this->assertStringContainsString('tnk_id', $capturedSql);
        $this->assertStringContainsString('tank',   $capturedSql);
    }

    // ----------------------------------------------------------------
    // getAllTankObj()
    // ----------------------------------------------------------------

    public function testGetAllTankObjReturnsArray(): void
    {
        $rows = [$this->makeTank(1), $this->makeTank(2)];
        $this->injectPdo($this->mockPdo($this->mockStmt(null, $rows)));

        $result = (new db_tank())->getAllTankObj();

        $this->assertIsArray($result);
        $this->assertCount(2, $result);
    }

    public function testGetAllTankObjReturnsEmptyArrayWhenNone(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(null, [])));

        $result = (new db_tank())->getAllTankObj();

        $this->assertIsArray($result);
        $this->assertEmpty($result);
    }

    public function testGetAllTankObjReturnsObjectsWithCorrectFields(): void
    {
        $rows = [$this->makeTank(7)];
        $this->injectPdo($this->mockPdo($this->mockStmt(null, $rows)));

        $result = (new db_tank())->getAllTankObj();

        $this->assertIsObject($result[0]);
        $this->assertSame(7,        $result[0]->tnk_id);
        $this->assertSame('diesel', $result[0]->tnk_type);
        $this->assertSame(5000.00,  $result[0]->tnk_fuel_volume);
    }

    public function testGetAllTankObjSqlFiltersOnIsActive(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(null, []), $capturedSql);
        $this->injectPdo($pdo);

        (new db_tank())->getAllTankObj();

        $this->assertStringContainsString('tnk_is_active', $capturedSql);
        $this->assertStringContainsString('1',             $capturedSql);
    }

    // ----------------------------------------------------------------
    // getTankObjByID()
    // ----------------------------------------------------------------

    public function testGetTankObjByIDReturnsObjectWhenFound(): void
    {
        $row = $this->makeTank(5);
        $this->injectPdo($this->mockPdo($this->mockStmt($row)));

        $result = (new db_tank())->getTankObjByID(5);

        $this->assertIsObject($result);
        $this->assertSame(5, $result->tnk_id);
    }

    public function testGetTankObjByIDReturnsCorrectFields(): void
    {
        $row = $this->makeTank(2);
        $this->injectPdo($this->mockPdo($this->mockStmt($row)));

        $result = (new db_tank())->getTankObjByID(2);

        $this->assertSame(10,       $result->tnk_ref_person);
        $this->assertSame(20,       $result->tnk_ref_manager);
        $this->assertSame(5000.00,  $result->tnk_fuel_volume);
        $this->assertSame('diesel', $result->tnk_type);
    }

    public function testGetTankObjByIDReturnsFalseWhenNotFound(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(false)));

        $result = (new db_tank())->getTankObjByID(9999);

        $this->assertFalse($result);
    }

    public function testGetTankObjByIDReturnsFalseOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('DB error'));
        $this->injectPdo($pdo);

        ob_start();
        $result = (new db_tank())->getTankObjByID(1);
        ob_end_clean();

        $this->assertFalse($result);
    }

    public function testGetTankObjByIDOutputsErrorOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('connection lost'));
        $this->injectPdo($pdo);

        ob_start();
        (new db_tank())->getTankObjByID(1);
        $output = ob_get_clean();

        $this->assertStringContainsString('Validation error:', $output);
    }

    public function testGetTankObjByIDSqlContainsTnkId(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(false), $capturedSql);
        $this->injectPdo($pdo);

        (new db_tank())->getTankObjByID(1);

        $this->assertStringContainsString('tnk_id', $capturedSql);
        $this->assertStringContainsString('WHERE',  $capturedSql);
    }

    // ----------------------------------------------------------------
    // getJoinedTanksAndPump()
    // ----------------------------------------------------------------

    public function testGetJoinedTanksAndPumpReturnsArray(): void
    {
        $rows = [$this->makeTank(1), $this->makeTank(2)];
        $this->injectPdo($this->mockPdo($this->mockStmt(null, $rows)));

        $result = (new db_tank())->getJoinedTanksAndPump();

        $this->assertIsArray($result);
        $this->assertCount(2, $result);
    }

    public function testGetJoinedTanksAndPumpReturnsEmptyArrayWhenNone(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(null, [])));

        $result = (new db_tank())->getJoinedTanksAndPump();

        $this->assertIsArray($result);
        $this->assertEmpty($result);
    }

    public function testGetJoinedTanksAndPumpSqlJoinsFuelPump(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(null, []), $capturedSql);
        $this->injectPdo($pdo);

        (new db_tank())->getJoinedTanksAndPump();

        $this->assertStringContainsString('LEFT JOIN', $capturedSql);
        $this->assertStringContainsString('fuel_pump', $capturedSql);
    }

    public function testGetJoinedTanksAndPumpSqlJoinsOnCorrectKeys(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(null, []), $capturedSql);
        $this->injectPdo($pdo);

        (new db_tank())->getJoinedTanksAndPump();

        $this->assertStringContainsString('tnk_id',      $capturedSql);
        $this->assertStringContainsString('flp_ref_tank',$capturedSql);
    }
}