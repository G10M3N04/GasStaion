<?php
// vendor\bin\phpunit tests\dbpersonTest.php

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../db/connection.php';
require_once __DIR__ . '/../db/db_base.php';
require_once __DIR__ . '/../db/db_person.php';
use PHPUnit\Framework\TestCase;


class DbPersonTest extends TestCase
{
    // ----------------------------------------------------------------
    // Helpers
    // ----------------------------------------------------------------

    private function mockStmt(mixed $fetchResult = null, array $fetchAllResult = []): PDOStatement
    {
        $stmt = $this->createMock(PDOStatement::class);
        $stmt->method('execute')->willReturn(true);
        $stmt->method('fetch')->willReturn($fetchResult);
        $stmt->method('fetchAll')->willReturn($fetchAllResult);
        return $stmt;
    }

    /**
     * Build a mock PDO that returns $stmt from ->prepare().
     */
    private function mockPdo(PDOStatement $stmt): PDO
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willReturn($stmt);
        return $pdo;
    }

    /**
     * Inject a PDO mock into db_connection's private static $conn.
     */
    private function injectPdo(PDO $pdo): void
    {
        $ref = new ReflectionProperty(db_connection::class, 'conn');
        $ref->setValue(null, $pdo);
    }

    /**
     * Reset db_connection singleton between tests.
     */
    private function resetConnection(): void
    {
        $ref = new ReflectionProperty(db_connection::class, 'conn');
        $ref->setValue(null, false);
    }

    protected function setUp(): void    { $this->resetConnection(); }
    protected function tearDown(): void { $this->resetConnection(); }

    // ----------------------------------------------------------------
    // set_default()
    // ----------------------------------------------------------------

    public function testSetDefaultPopulatesValueArr(): void
    {
        $p = new db_person();
        $p->set_default();

        $this->assertIsArray($p->value_arr);
        $this->assertArrayHasKey('per_id',         $p->value_arr);
        $this->assertArrayHasKey('per_firstname',  $p->value_arr);
        $this->assertArrayHasKey('per_lastname',   $p->value_arr);
        $this->assertArrayHasKey('per_username',   $p->value_arr);
        $this->assertArrayHasKey('per_password',   $p->value_arr);
        $this->assertArrayHasKey('per_email',      $p->value_arr);
        $this->assertArrayHasKey('per_phone',      $p->value_arr);
        $this->assertArrayHasKey('per_idnr',       $p->value_arr);
        $this->assertArrayHasKey('per_dob',        $p->value_arr);
        $this->assertArrayHasKey('per_gender',     $p->value_arr);
        $this->assertArrayHasKey('per_ethnicity',  $p->value_arr);
        $this->assertArrayHasKey('per_date_added', $p->value_arr);
        $this->assertArrayHasKey('per_is_active',  $p->value_arr);
    }

    public function testSetDefaultSetsEmptyStringDefaults(): void
    {
        $p = new db_person();
        $p->set_default();

        foreach ($p->value_arr as $key => $value) {
            $this->assertSame('', $value, "Expected empty default for field '$key'");
        }
    }

    public function testFieldArrHasThirteenFields(): void
    {
        $p = new db_person();
        $this->assertCount(13, $p->field_arr);
    }

    // ----------------------------------------------------------------
    // usernameExists()
    // ----------------------------------------------------------------

    public function testUsernameExistsReturnsTrueWhenFound(): void
    {
        $stmt = $this->mockStmt(['count' => 1]);
        $this->injectPdo($this->mockPdo($stmt));

        $p = new db_person();
        $this->assertTrue($p->usernameExists('john_doe'));
    }

    public function testUsernameExistsReturnsFalseWhenNotFound(): void
    {
        $stmt = $this->mockStmt(['count' => 0]);
        $this->injectPdo($this->mockPdo($stmt));

        $p = new db_person();
        $this->assertFalse($p->usernameExists('ghost_user'));
    }

    public function testUsernameExistsReturnsFalseOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('DB error'));
        $this->injectPdo($pdo);

        ob_start();
        $result = (new db_person())->usernameExists('any');
        ob_end_clean();

        $this->assertFalse($result);
    }

    // ----------------------------------------------------------------
    // emailExists()
    // ----------------------------------------------------------------

    public function testEmailExistsReturnsTrueWhenFound(): void
    {
        $stmt = $this->mockStmt(['count' => 3]);
        $this->injectPdo($this->mockPdo($stmt));

        $this->assertTrue((new db_person())->emailExists('user@example.com'));
    }

    public function testEmailExistsReturnsFalseWhenNotFound(): void
    {
        $stmt = $this->mockStmt(['count' => 0]);
        $this->injectPdo($this->mockPdo($stmt));

        $this->assertFalse((new db_person())->emailExists('nobody@example.com'));
    }

    public function testEmailExistsReturnsFalseOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('fail'));
        $this->injectPdo($pdo);

        ob_start();
        $result = (new db_person())->emailExists('x@y.com');
        ob_end_clean();

        $this->assertFalse($result);
    }

    // ----------------------------------------------------------------
    // passwordExists()
    // ----------------------------------------------------------------

    public function testPasswordExistsReturnsTrueWhenFound(): void
    {
        $stmt = $this->mockStmt(['count' => 1]);
        $this->injectPdo($this->mockPdo($stmt));

        $this->assertTrue((new db_person())->passwordExists('secret'));
    }

    public function testPasswordExistsReturnsFalseWhenNotFound(): void
    {
        $stmt = $this->mockStmt(['count' => 0]);
        $this->injectPdo($this->mockPdo($stmt));

        $this->assertFalse((new db_person())->passwordExists('wrongpass'));
    }

    public function testPasswordExistsReturnsFalseOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('fail'));
        $this->injectPdo($pdo);

        ob_start();
        $result = (new db_person())->passwordExists('any');
        ob_end_clean();

        $this->assertFalse($result);
    }

    // ----------------------------------------------------------------
    // getPersonByUsername()
    // ----------------------------------------------------------------

    public function testGetPersonByUsernameReturnsObjectWhenFound(): void
    {
        $row = (object)['per_id' => 42];
        $stmt = $this->mockStmt($row);
        $this->injectPdo($this->mockPdo($stmt));

        $result = (new db_person())->getPersonByUsername('john_doe');

        $this->assertIsObject($result);
        $this->assertSame(42, $result->per_id);
    }

    public function testGetPersonByUsernameReturnsFalseWhenNotFound(): void
    {
        $stmt = $this->mockStmt(false);
        $this->injectPdo($this->mockPdo($stmt));

        $this->assertFalse((new db_person())->getPersonByUsername('nobody'));
    }

    public function testGetPersonByUsernameReturnsFalseOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('fail'));
        $this->injectPdo($pdo);

        ob_start();
        $result = (new db_person())->getPersonByUsername('any');
        ob_end_clean();

        $this->assertFalse($result);
    }

    // ----------------------------------------------------------------
    // getPersonByID()
    // ----------------------------------------------------------------

    public function testGetPersonByIDReturnsObjectWithNames(): void
    {
        $row = (object)['per_firstname' => 'Jane', 'per_lastname' => 'Doe'];
        $stmt = $this->mockStmt($row);
        $this->injectPdo($this->mockPdo($stmt));

        $result = (new db_person())->getPersonByID(1);

        $this->assertIsObject($result);
        $this->assertSame('Jane', $result->per_firstname);
        $this->assertSame('Doe',  $result->per_lastname);
    }

    public function testGetPersonByIDReturnsFalseWhenNotFound(): void
    {
        $stmt = $this->mockStmt(false);
        $this->injectPdo($this->mockPdo($stmt));

        $this->assertFalse((new db_person())->getPersonByID(9999));
    }

    public function testGetPersonByIDReturnsFalseOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('fail'));
        $this->injectPdo($pdo);

        ob_start();
        $result = (new db_person())->getPersonByID(1);
        ob_end_clean();

        $this->assertFalse($result);
    }

    // ----------------------------------------------------------------
    // getPersonAllActive()
    // ----------------------------------------------------------------

    public function testGetPersonAllActiveReturnsArrayOfObjects(): void
    {
        $rows = [
            (object)['full_name' => 'Jane Doe', 'per_idnr' => 'ID001', 'per_phone' => '0821234567', 'per_email' => 'jane@x.com', 'per_id' => 1],
            (object)['full_name' => 'John Smith', 'per_idnr' => 'ID002', 'per_phone' => '0837654321', 'per_email' => 'john@x.com', 'per_id' => 2],
        ];

        $stmt = $this->mockStmt(null, $rows);
        $this->injectPdo($this->mockPdo($stmt));

        $result = (new db_person())->getPersonAllActive();

        $this->assertIsArray($result);
        $this->assertCount(2, $result);
        $this->assertSame('Jane Doe', $result[0]->full_name);
    }

    public function testGetPersonAllActiveReturnsEmptyArrayWhenNone(): void
    {
        $stmt = $this->mockStmt(null, []);
        $this->injectPdo($this->mockPdo($stmt));

        $result = (new db_person())->getPersonAllActive();

        $this->assertIsArray($result);
        $this->assertEmpty($result);
    }

    public function testGetPersonAllActiveReturnsFalseOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('fail'));
        $this->injectPdo($pdo);

        ob_start();
        $result = (new db_person())->getPersonAllActive();
        ob_end_clean();

        $this->assertFalse($result);
    }

    // ----------------------------------------------------------------
    // getPersonObjByID()
    // ----------------------------------------------------------------

    public function testGetPersonObjByIDReturnsFullObject(): void
    {
        $row = (object)[
            'per_id'        => 5,
            'per_firstname' => 'Alice',
            'per_lastname'  => 'Smith',
            'per_username'  => 'asmith',
            'per_email'     => 'alice@example.com',
        ];
        $stmt = $this->mockStmt($row);
        $this->injectPdo($this->mockPdo($stmt));

        $result = (new db_person())->getPersonObjByID(5);

        $this->assertIsObject($result);
        $this->assertSame(5,       $result->per_id);
        $this->assertSame('Alice', $result->per_firstname);
    }

    public function testGetPersonObjByIDReturnsFalseWhenNotFound(): void
    {
        $stmt = $this->mockStmt(false);
        $this->injectPdo($this->mockPdo($stmt));

        $this->assertFalse((new db_person())->getPersonObjByID(9999));
    }

    public function testGetPersonObjByIDReturnsFalseOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('fail'));
        $this->injectPdo($pdo);

        ob_start();
        $result = (new db_person())->getPersonObjByID(1);
        ob_end_clean();

        $this->assertFalse($result);
    }

    // ----------------------------------------------------------------
    // Class structure
    // ----------------------------------------------------------------

    public function testTablePropertyIsCorrect(): void
    {
        $this->assertSame('person', (new db_person())->table);
    }

    public function testValueArrStartsEmpty(): void
    {
        $this->assertSame([], (new db_person())->value_arr);
    }
}