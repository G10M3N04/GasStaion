<?php
// vendor\bin\phpunit tests\dbproductTest.php

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../db/connection.php';
require_once __DIR__ . '/../db/db_base.php';
require_once __DIR__ . '/../db/db_product.php';

use PHPUnit\Framework\TestCase;

class DbProductTest extends TestCase
{
    // ----------------------------------------------------------------
    // Helpers
    // ----------------------------------------------------------------

    private function injectPdo(PDO $pdo): void
    {
        $ref = new ReflectionProperty(db_connection::class, 'conn');
        $ref->setValue(null, $pdo);
    }

    private function resetConnection(): void
    {
        $ref = new ReflectionProperty(db_connection::class, 'conn');
        $ref->setValue(null, false);
    }

    protected function setUp(): void    { $this->resetConnection(); }
    protected function tearDown(): void { $this->resetConnection(); }

    /**
     * Build a mock PDOStatement with controllable fetch/fetchAll returns.
     */
    private function mockStmt(mixed $fetchResult = null, array $fetchAllResult = []): PDOStatement
    {
        $stmt = $this->createMock(PDOStatement::class);
        $stmt->method('execute')->willReturn(true);
        $stmt->method('fetch')->willReturn($fetchResult);
        $stmt->method('fetchAll')->willReturn($fetchAllResult);
        return $stmt;
    }

    /**
     * Build a mock PDO that returns $stmt from prepare().
     */
    private function mockPdo(PDOStatement $stmt): PDO
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willReturn($stmt);
        $pdo->method('setAttribute')->willReturn(true);
        return $pdo;
    }

    /**
     * Build a mock PDO that captures the SQL passed to prepare().
     */
    private function mockPdoCapturingSql(PDOStatement $stmt, string &$capturedSql): PDO
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('setAttribute')->willReturn(true);
        $pdo->method('prepare')->willReturnCallback(
            function (string $sql) use ($stmt, &$capturedSql) {
                $capturedSql = $sql;
                return $stmt;
            }
        );
        return $pdo;
    }

    /**
     * Build a sample product object the way the DB would return one.
     */
    private function makeProduct(int $id = 1, string $category = 'fuel'): object
    {
        return (object)[
            'pro_id'       => $id,
            'pro_name'     => 'Product ' . $id,
            'pro_category' => $category,
            'pro_price'    => 10.99,
            'pro_quantity' => 100,
            'pro_is_active'=> 1,
        ];
    }

    // ----------------------------------------------------------------
    // Class structure
    // ----------------------------------------------------------------

    public function testTablePropertyIsProduct(): void
    {
        $this->assertSame('product', (new db_product())->table);
    }

    public function testFieldArrHasSixFields(): void
    {
        $this->assertCount(6, (new db_product())->field_arr);
    }

    public function testValueArrStartsEmpty(): void
    {
        $this->assertSame([], (new db_product())->value_arr);
    }

    // ----------------------------------------------------------------
    // set_default()
    // ----------------------------------------------------------------

    public function testSetDefaultPopulatesAllKeys(): void
    {
        $p = new db_product();
        $p->set_default();

        $this->assertArrayHasKey('pro_id',        $p->value_arr);
        $this->assertArrayHasKey('pro_name',      $p->value_arr);
        $this->assertArrayHasKey('pro_category',  $p->value_arr);
        $this->assertArrayHasKey('pro_price',     $p->value_arr);
        $this->assertArrayHasKey('pro_quantity',  $p->value_arr);
        $this->assertArrayHasKey('pro_is_active', $p->value_arr);
    }

    public function testSetDefaultSetsEmptyStringDefaults(): void
    {
        $p = new db_product();
        $p->set_default();

        foreach ($p->value_arr as $key => $value) {
            $this->assertSame('', $value, "Expected empty default for '$key'");
        }
    }

    public function testSetDefaultCountMatchesFieldArr(): void
    {
        $p = new db_product();
        $p->set_default();

        $this->assertCount(count($p->field_arr), $p->value_arr);
    }

    // ----------------------------------------------------------------
    // getProductsByCategory()
    // ----------------------------------------------------------------

    public function testGetProductsByCategoryReturnsArray(): void
    {
        $rows = [$this->makeProduct(1, 'fuel'), $this->makeProduct(2, 'fuel')];
        $this->injectPdo($this->mockPdo($this->mockStmt(null, $rows)));

        $result = (new db_product())->getProductsByCategory('fuel');

        $this->assertIsArray($result);
        $this->assertCount(2, $result);
    }

    public function testGetProductsByCategoryReturnsCorrectCategory(): void
    {
        $rows = [$this->makeProduct(1, 'oil')];
        $this->injectPdo($this->mockPdo($this->mockStmt(null, $rows)));

        $result = (new db_product())->getProductsByCategory('oil');

        $this->assertSame('oil', $result[0]->pro_category);
    }

    public function testGetProductsByCategoryReturnsEmptyArrayWhenNoneFound(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(null, [])));

        $result = (new db_product())->getProductsByCategory('nonexistent');

        $this->assertIsArray($result);
        $this->assertEmpty($result);
    }

    public function testGetProductsByCategorySqlContainsProCategory(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(null, []), $capturedSql);
        $this->injectPdo($pdo);

        (new db_product())->getProductsByCategory('fuel');

        $this->assertStringContainsString('pro_category', $capturedSql);
    }

    // ----------------------------------------------------------------
    // getAllProducts()
    // ----------------------------------------------------------------

    public function testGetAllProductsReturnsArrayOfObjects(): void
    {
        $rows = [$this->makeProduct(1), $this->makeProduct(2), $this->makeProduct(3)];
        $this->injectPdo($this->mockPdo($this->mockStmt(null, $rows)));

        $result = (new db_product())->getAllProducts();

        $this->assertIsArray($result);
        $this->assertCount(3, $result);
        $this->assertIsObject($result[0]);
    }

    public function testGetAllProductsReturnsEmptyArrayWhenNoneActive(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(null, [])));

        $result = (new db_product())->getAllProducts();

        $this->assertIsArray($result);
        $this->assertEmpty($result);
    }

    public function testGetAllProductsSqlFiltersOnIsActive(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(null, []), $capturedSql);
        $this->injectPdo($pdo);

        (new db_product())->getAllProducts();

        $this->assertStringContainsString('pro_is_active', $capturedSql);
        $this->assertStringContainsString('1', $capturedSql);
    }

    public function testGetAllProductsReturnsFalseOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('DB error'));
        $this->injectPdo($pdo);

        ob_start();
        $result = (new db_product())->getAllProducts();
        ob_end_clean();

        $this->assertFalse($result);
    }

    public function testGetAllProductsOutputsErrorMessageOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('connection lost'));
        $this->injectPdo($pdo);

        ob_start();
        (new db_product())->getAllProducts();
        $output = ob_get_clean();

        $this->assertStringContainsString('Validation error:', $output);
    }

    // ----------------------------------------------------------------
    // getProductObjByID()
    // ----------------------------------------------------------------

    public function testGetProductObjByIDReturnsObjectWhenFound(): void
    {
        $row = $this->makeProduct(5);
        $this->injectPdo($this->mockPdo($this->mockStmt($row)));

        $result = (new db_product())->getProductObjByID(5);

        $this->assertIsObject($result);
        $this->assertSame(5, $result->pro_id);
    }

    public function testGetProductObjByIDReturnsCorrectFields(): void
    {
        $row = $this->makeProduct(3, 'edible');
        $this->injectPdo($this->mockPdo($this->mockStmt($row)));

        $result = (new db_product())->getProductObjByID(3);

        $this->assertSame('edible',      $result->pro_category);
        $this->assertSame('Product 3',   $result->pro_name);
        $this->assertSame(10.99,         $result->pro_price);
    }

    public function testGetProductObjByIDReturnsFalseWhenNotFound(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(false)));

        $result = (new db_product())->getProductObjByID(9999);

        $this->assertFalse($result);
    }

    public function testGetProductObjByIDReturnsFalseOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('DB error'));
        $this->injectPdo($pdo);

        ob_start();
        $result = (new db_product())->getProductObjByID(1);
        ob_end_clean();

        $this->assertFalse($result);
    }

    public function testGetProductObjByIDSqlContainsProId(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(false), $capturedSql);
        $this->injectPdo($pdo);

        (new db_product())->getProductObjByID(1);

        $this->assertStringContainsString('pro_id', $capturedSql);
    }

    // ----------------------------------------------------------------
    // getAllProductExceptEdible()
    // ----------------------------------------------------------------

    public function testGetAllProductExceptEdibleReturnsArray(): void
    {
        $rows = [$this->makeProduct(1, 'fuel'), $this->makeProduct(2, 'oil')];
        $this->injectPdo($this->mockPdo($this->mockStmt(null, $rows)));

        $result = (new db_product())->getAllProductExceptEdible();

        $this->assertIsArray($result);
        $this->assertCount(2, $result);
    }

    public function testGetAllProductExceptEdibleReturnsEmptyWhenNone(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(null, [])));

        $result = (new db_product())->getAllProductExceptEdible();

        $this->assertIsArray($result);
        $this->assertEmpty($result);
    }

    public function testGetAllProductExceptEdibleSqlExcludesEdible(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(null, []), $capturedSql);
        $this->injectPdo($pdo);

        (new db_product())->getAllProductExceptEdible();

        $this->assertStringContainsString('edible', $capturedSql);
        $this->assertStringContainsString('<>', $capturedSql);
    }

    public function testGetAllProductExceptEdibleReturnsFalseOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('DB error'));
        $this->injectPdo($pdo);

        ob_start();
        $result = (new db_product())->getAllProductExceptEdible();
        ob_end_clean();

        $this->assertFalse($result);
    }

    // ----------------------------------------------------------------
    // getAllProductsByCategories()
    // ----------------------------------------------------------------

    public function testGetAllProductsByCategoriesReturnsArray(): void
    {
        $rows = [$this->makeProduct(1, 'fuel'), $this->makeProduct(2, 'fuel')];
        $this->injectPdo($this->mockPdo($this->mockStmt(null, $rows)));

        $result = (new db_product())->getAllProductsByCategories('fuel');

        $this->assertIsArray($result);
        $this->assertCount(2, $result);
    }

    public function testGetAllProductsByCategoriesReturnsObjectsWithCorrectCategory(): void
    {
        $rows = [$this->makeProduct(1, 'oil')];
        $this->injectPdo($this->mockPdo($this->mockStmt(null, $rows)));

        $result = (new db_product())->getAllProductsByCategories('oil');

        $this->assertSame('oil', $result[0]->pro_category);
    }

    public function testGetAllProductsByCategoriesReturnsEmptyArrayWhenNone(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(null, [])));

        $result = (new db_product())->getAllProductsByCategories('nonexistent');

        $this->assertIsArray($result);
        $this->assertEmpty($result);
    }

    public function testGetAllProductsByCategoriesSqlContainsProCategory(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(null, []), $capturedSql);
        $this->injectPdo($pdo);

        (new db_product())->getAllProductsByCategories('fuel');

        $this->assertStringContainsString('pro_category', $capturedSql);
    }

    public function testGetAllProductsByCategoriesReturnsFalseOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('DB error'));
        $this->injectPdo($pdo);

        ob_start();
        $result = (new db_product())->getAllProductsByCategories('fuel');
        ob_end_clean();

        $this->assertFalse($result);
    }

    public function testGetAllProductsByCategoriesOutputsErrorOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('connection lost'));
        $this->injectPdo($pdo);

        ob_start();
        (new db_product())->getAllProductsByCategories('fuel');
        $output = ob_get_clean();

        $this->assertStringContainsString('Validation error:', $output);
    }
}