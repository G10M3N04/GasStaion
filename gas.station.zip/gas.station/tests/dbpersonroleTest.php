<?php
// vendor\bin\phpunit tests\dbpersonroleTest.php

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../db/connection.php';
require_once __DIR__ . '/../db/db_base.php';
require_once __DIR__ . '/../db/db_person.php';
require_once __DIR__ . '/../db/db_person_role.php';

use PHPUnit\Framework\TestCase;


class DbPersonRoleTest extends TestCase
{
    // ----------------------------------------------------------------
    // Helpers
    // ----------------------------------------------------------------

    private function injectPdo(PDO $pdo): void
    {
        $ref = new ReflectionProperty(db_connection::class, 'conn');
        $ref->setValue(null, $pdo);
    }

    private function resetConnection(): void
    {
        $ref = new ReflectionProperty(db_connection::class, 'conn');
        $ref->setValue(null, false);
    }

    protected function setUp(): void    { $this->resetConnection(); }
    protected function tearDown(): void { $this->resetConnection(); }

    /**
     * Build a mock PDOStatement with a controllable fetch() return.
     */
    private function mockStmt(mixed $fetchResult = null): PDOStatement
    {
        $stmt = $this->createMock(PDOStatement::class);
        $stmt->method('execute')->willReturn(true);
        $stmt->method('fetch')->willReturn($fetchResult);
        return $stmt;
    }

    /**
     * Build a mock PDO that returns $stmt from prepare().
     */
    private function mockPdo(PDOStatement $stmt): PDO
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willReturn($stmt);
        $pdo->method('setAttribute')->willReturn(true);
        return $pdo;
    }

    /**
     * Build a mock PDO that captures the SQL passed to prepare().
     */
    private function mockPdoCapturingSql(PDOStatement $stmt, string &$capturedSql): PDO
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('setAttribute')->willReturn(true);
        $pdo->method('prepare')->willReturnCallback(
            function (string $sql) use ($stmt, &$capturedSql) {
                $capturedSql = $sql;
                return $stmt;
            }
        );
        return $pdo;
    }

    // ----------------------------------------------------------------
    // Class structure
    // ----------------------------------------------------------------

    public function testTablePropertyIsPersonRole(): void
    {
        $this->assertSame('person_role', (new db_person_role())->table);
    }

    public function testFieldArrHasThreeFields(): void
    {
        $this->assertCount(3, (new db_person_role())->field_arr);
    }

    public function testValueArrStartsEmpty(): void
    {
        $this->assertSame([], (new db_person_role())->value_arr);
    }

    public function testFieldArrContainsExpectedFieldNames(): void
    {
        $fields = array_column((new db_person_role())->field_arr, 'field');

        $this->assertContains('prl_id',         $fields);
        $this->assertContains('prl_ref_acl',    $fields);
        $this->assertContains('prl_ref_person', $fields);
    }

    // ----------------------------------------------------------------
    // set_default()
    // ----------------------------------------------------------------

    public function testSetDefaultPopulatesAllKeys(): void
    {
        $p = new db_person_role();
        $p->set_default();

        $this->assertArrayHasKey('prl_id',         $p->value_arr);
        $this->assertArrayHasKey('prl_ref_acl',    $p->value_arr);
        $this->assertArrayHasKey('prl_ref_person', $p->value_arr);
    }

    public function testSetDefaultSetsEmptyStringDefaults(): void
    {
        $p = new db_person_role();
        $p->set_default();

        foreach ($p->value_arr as $key => $value) {
            $this->assertSame('', $value, "Expected empty default for '$key'");
        }
    }

    public function testSetDefaultCountMatchesFieldArr(): void
    {
        $p = new db_person_role();
        $p->set_default();

        $this->assertCount(count($p->field_arr), $p->value_arr);
    }

    // ----------------------------------------------------------------
    // getPersonRoleById()
    // ----------------------------------------------------------------

    public function testGetPersonRoleByIdReturnsObjectWhenFound(): void
    {
        $row = (object)['prl_ref_acl' => 3];
        $this->injectPdo($this->mockPdo($this->mockStmt($row)));

        $result = (new db_person_role())->getPersonRoleById(1);

        $this->assertIsObject($result);
        $this->assertSame(3, $result->prl_ref_acl);
    }

    public function testGetPersonRoleByIdReturnsFalseWhenNotFound(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(false)));

        $result = (new db_person_role())->getPersonRoleById(9999);

        $this->assertFalse($result);
    }

    public function testGetPersonRoleByIdReturnsFalseOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('DB error'));
        $this->injectPdo($pdo);

        ob_start();
        $result = (new db_person_role())->getPersonRoleById(1);
        ob_end_clean();

        $this->assertFalse($result);
    }

    public function testGetPersonRoleByIdOutputsErrorOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('connection lost'));
        $this->injectPdo($pdo);

        ob_start();
        (new db_person_role())->getPersonRoleById(1);
        $output = ob_get_clean();

        $this->assertStringContainsString('Validation error:', $output);
    }

    public function testGetPersonRoleByIdSqlSelectsPrlRefAcl(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(false), $capturedSql);
        $this->injectPdo($pdo);

        (new db_person_role())->getPersonRoleById(1);

        $this->assertStringContainsString('prl_ref_acl', $capturedSql);
    }

    public function testGetPersonRoleByIdSqlFiltersOnPrlRefPerson(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(false), $capturedSql);
        $this->injectPdo($pdo);

        (new db_person_role())->getPersonRoleById(1);

        $this->assertStringContainsString('prl_ref_person', $capturedSql);
    }

    public function testGetPersonRoleByIdSqlQueriesPersonRoleTable(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(false), $capturedSql);
        $this->injectPdo($pdo);

        (new db_person_role())->getPersonRoleById(1);

        $this->assertStringContainsString('person_role', $capturedSql);
    }

    // ----------------------------------------------------------------
    // getPersonRoleId()
    // ----------------------------------------------------------------

    public function testGetPersonRoleIdReturnsObjectWhenFound(): void
    {
        $row = (object)['prl_id' => 7];
        $this->injectPdo($this->mockPdo($this->mockStmt($row)));

        $result = (new db_person_role())->getPersonRoleId(2);

        $this->assertIsObject($result);
        $this->assertSame(7, $result->prl_id);
    }

    public function testGetPersonRoleIdReturnsFalseWhenNotFound(): void
    {
        $this->injectPdo($this->mockPdo($this->mockStmt(false)));

        $result = (new db_person_role())->getPersonRoleId(9999);

        $this->assertFalse($result);
    }

    public function testGetPersonRoleIdReturnsFalseOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('DB error'));
        $this->injectPdo($pdo);

        ob_start();
        $result = (new db_person_role())->getPersonRoleId(1);
        ob_end_clean();

        $this->assertFalse($result);
    }

    public function testGetPersonRoleIdOutputsErrorOnException(): void
    {
        $pdo = $this->createMock(PDO::class);
        $pdo->method('prepare')->willThrowException(new PDOException('connection lost'));
        $this->injectPdo($pdo);

        ob_start();
        (new db_person_role())->getPersonRoleId(1);
        $output = ob_get_clean();

        $this->assertStringContainsString('Validation error:', $output);
    }

    public function testGetPersonRoleIdSqlSelectsPrlId(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(false), $capturedSql);
        $this->injectPdo($pdo);

        (new db_person_role())->getPersonRoleId(1);

        $this->assertStringContainsString('prl_id', $capturedSql);
    }

    public function testGetPersonRoleIdSqlFiltersOnPrlRefPerson(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(false), $capturedSql);
        $this->injectPdo($pdo);

        (new db_person_role())->getPersonRoleId(1);

        $this->assertStringContainsString('prl_ref_person', $capturedSql);
    }

    public function testGetPersonRoleIdSqlQueriesPersonRoleTable(): void
    {
        $capturedSql = "";
        $pdo = $this->mockPdoCapturingSql($this->mockStmt(false), $capturedSql);
        $this->injectPdo($pdo);

        (new db_person_role())->getPersonRoleId(1);

        $this->assertStringContainsString('person_role', $capturedSql);
    }

    // ----------------------------------------------------------------
    // Distinction between the two methods
    // ----------------------------------------------------------------

    public function testGetPersonRoleByIdAndGetPersonRoleIdSelectDifferentColumns(): void
    {
        $sqlById    = "";
        $sqlByRoleId = "";

        $pdo1 = $this->mockPdoCapturingSql($this->mockStmt(false), $sqlById);
        $this->injectPdo($pdo1);
        (new db_person_role())->getPersonRoleById(1);

        $this->resetConnection();

        $pdo2 = $this->mockPdoCapturingSql($this->mockStmt(false), $sqlByRoleId);
        $this->injectPdo($pdo2);
        (new db_person_role())->getPersonRoleId(1);

        // getPersonRoleById selects prl_ref_acl; getPersonRoleId selects prl_id
        $this->assertStringContainsString('prl_ref_acl', $sqlById);
        $this->assertStringContainsString('prl_id',      $sqlByRoleId);
        $this->assertStringNotContainsString('prl_id',      $sqlById);
        $this->assertStringNotContainsString('prl_ref_acl', $sqlByRoleId);
    }
}