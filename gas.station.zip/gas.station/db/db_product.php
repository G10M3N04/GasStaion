<?php
include_once "../db/connection.php";

class db_product extends db_base{

    public $table="product";
    public $field_arr = [

        0 =>[
            "field" => "pro_id", 
            "type" => "int",
            "default" => ""
        ],
        1 =>[
            "field" => "pro_name",
            "type" => "string",
            "default" => ""

        ],
        2 =>[
            "field" => "pro_category",
            "type" => "string",
            "default" => ""        
        ],
        3 =>[
            "field" => "pro_price",
            "type" => "currency",
            "default" => ""        
        ],
        4 =>[
            "field" => "pro_quantity",
            "type" => "int",
            "default" => ""        
        ],
        5 =>[
            "field" => "pro_is_active",
            "type" => "bool",
            "default" => ""        
        ],
    ];
    
    public $value_arr = [];

    function set_default(){
         foreach($this->field_arr as $field)  {
            $this->value_arr[$field["field"]] = $field["default"];
         } 
    }
    
    function getProductsByCategory($pro_category){

    $conn = \db_connection::connection();

    $sql = "SELECT * FROM product WHERE pro_category = :pro_category";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['pro_category' => $pro_category]);
    return $stmt->fetchAll(PDO::FETCH_OBJ); 
    }

    public function getAllProducts() {
        try {

            $sql = "SELECT * FROM product WHERE pro_is_active = 1";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }

    public function getProductObjByID($pro_id) {
        try {

            $sql = "SELECT * FROM product WHERE pro_id = :pro_id";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute([':pro_id' => $pro_id]);
            return $stmt->fetch(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }

    public function getAllProductExceptEdible() {
        try {

            $sql = "SELECT * FROM product WHERE pro_category <> 'edible'";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }

    public function getAllProductsByCategories($pro_category) {
        try {

            $sql = "SELECT * FROM product WHERE pro_category = :pro_category";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute([":pro_category"=> $pro_category]);
            return $stmt->fetchAll(PDO::FETCH_OBJ);

        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }

    
}
 ?>
