<?php
include_once "../db/connection.php";

class db_cashup extends db_base{

    public $table="cashup";
    public $field_arr = [

        0 =>[
            "field" => "cap_id", 
            "type" => "int",
            "default" => ""
        ],
        1 =>[
            "field" => "cap_ref_shift",
            "type" => "int",
            "default" => ""
        ],
        2 =>[
            "field" => "cap_ref_person",
            "type" => "id",
            "default" => ""        
        ],
        3 =>[
            "field" => "cap_opening_amount",
            "type" => "decimal",
            "default" => ""        
        ],
        4 =>[
            "field" => "cap_closing_amount",
            "type" => "decimal",
            "default" => ""        
        ],
        5 =>[
            "field" => "cap_total_sales",
            "type" => "decimal",
            "default" => ""        
        ],
        6 =>[
            "field" => "cap_date",
            "type" => "datetime",
            "default" => ""        
        ],
        7 =>[
            "field" => "cap_is_active",
            "type" => "int",
            "default" => ""        
        ],


        
        
    ];

    public $value_arr = [];

    function set_default(){
         foreach($this->field_arr as $field)  {
            $this->value_arr[$field["field"]] = $field["default"];
         } 
    }

   public function getAllCashups() {
        try {

            $sql = "SELECT * FROM cashup WHERE cap_is_active = 1";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }

    public function getCashupObjByID($cap_id) {
        try {

            $sql = "SELECT * FROM cashup WHERE cap_id = :cap_id";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute([':cap_id' => $cap_id]);
            return $stmt->fetch(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }
    

}
?>
