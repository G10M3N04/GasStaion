<?php
include_once "../db/connection.php";

class db_fuel_readings extends db_base{

    public $table="fuel_readings";
    public $field_arr = [

        0 =>[
            "field" => "flr_id", 
            "type" => "int",
            "default" => ""
        ],
        1 =>[
            "field" => "flr_ref_fuel_pump",
            "type" => "int",
            "default" => ""
        ],
        2 =>[
            "field" => "flr_ref_shift",
            "type" => "int",
            "default" => ""        
        ],
        3 =>[
            "field" => "flr_opening_readings",
            "type" => "decimal",
            "default" => ""        
        ],
        4 =>[
            "field" => "flr_closing_readings",
            "type" => "decimal",
            "default" => ""        
        ],
        5 =>[
            "field" => "flr_recorded_date",
            "type" => "date",
            "default" => ""        
        ],
    ];

    public $value_arr = [];

    function set_default(){
         foreach($this->field_arr as $field)  {
            $this->value_arr[$field["field"]] = $field["default"];
         } 
    }

    function getAllFuelObj(){

    $sql = "SELECT * FROM fuel_readings";
    $conn = \db_connection::connection();
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_OBJ);
    }

    public function getFuelReadingsObjByID($flr_id) {
        try {

            $sql = "SELECT * FROM fuel_readings WHERE flr_id = :flr_id";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute([':flr_id' => $flr_id]);
            return $stmt->fetch(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }
}
 ?>
