<?php
include_once "../db/connection.php";

class db_audit_log{

    public $table="audit_log";
    public $field_arr = [

        0 =>[
            "field" => "aul_id", 
            "type" => "int",
            "default" => ""
        ],
        1 =>[
            "field" => "aul_ref_person",
            "type" => "int",
            "default" => ""

        ],
        2 =>[
            "field" => "aul_action",
            "type" => "string",
            "default" => ""        
        ],
        3 =>[
            "field" => "aul_entity",
            "type" => "string",
            "default" => ""        
        ],
    ];

    public $value_arr = [];

    function set_default(){
         foreach($this->field_arr as $field)  {
            $this->value_arr[$field["field"]] = $field["default"];
         } 
    }
}
 ?>
