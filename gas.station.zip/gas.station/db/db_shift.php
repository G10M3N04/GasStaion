<?php
include_once "../db/connection.php";

class db_shift{

    public $table="shift";
    public $field_arr = [

        0 =>[
            "field" => "sft_id", 
            "type" => "int",
            "default" => ""
        ],
        1 =>[
            "field" => "sft_ref_person",
            "type" => "int",
            "default" => ""        
        ],
        2 =>[
            "field" => "sft_start_time",
            "type" => "datetime",
            "default" => ""

        ],
        3 =>[
            "field" => "sft_end_time",
            "type" => "datetime",
            "default" => ""        
        ],
        4 =>[
            "field" => "sft_total_sales",
            "type" => "currency",
            "default" => ""        
        ],
    ];

    public $value_arr = [];

    function set_default(){
         foreach($this->field_arr as $field)  {
            $this->value_arr[$field["field"]] = $field["default"];
         } 
    }
}
 ?>
