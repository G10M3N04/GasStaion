<?php
include_once "../db/connection.php";

class db_sale_items{

    public $table="sale_items";
    public $field_arr = [

        0 =>[
            "field" => "sit_id", 
            "type" => "int",
            "default" => ""
        ],
        1 =>[
            "field" => "sit_ref_person",
            "type" => "int",
            "default" => ""        
        ],
        2 =>[
            "field" => "sit_ref_transactions",
            "type" => "int",
            "default" => ""

        ],
        3 =>[
            "field" => "sit_ref_product",
            "type" => "int",
            "default" => ""        
        ],
        4 =>[
            "field" => "sit_quantity",
            "type" => "int",
            "default" => ""        
        ],
        5 =>[
            "field" => "sit_subtotal",
            "type" => "currency",
            "default" => ""        
        ],
    ];

    public $value_arr = [];

    function set_default(){
         foreach($this->field_arr as $field)  {
            $this->value_arr[$field["field"]] = $field["default"];
         } 
    }
}
 ?>
