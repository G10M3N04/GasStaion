<?php
include_once "../db/connection.php";
include_once "../db/db_person.php";
require_once "C:\Projects\gas.station\db\db_base.php";

class db_person_role extends db_base{

    public $table="person_role";
    public $field_arr = [

        0 =>[
            "field" => "prl_id", 
            "type" => "int",
            "default" => ""
        ],
        1 =>[
            "field" => "prl_ref_acl",
            "type" => "int",
            "default" => ""

        ],
        2 =>[
            "field" => "prl_ref_person",
            "type" => "int",
            "default" => ""        
        ],
    ];

    public $value_arr = [];

    function set_default(){
         foreach($this->field_arr as $field)  {
            $this->value_arr[$field["field"]] = $field["default"];
         } 
    }

    function getPersonRoleById($per_id) {
        try {
            $sql = "SELECT prl_ref_acl FROM person_role WHERE prl_ref_person = :per_id";
            $conn = \db_connection::connection();           
            $stmt = $conn->prepare($sql);
            $stmt->execute([':per_id' => $per_id]);
            // print_r($per_id);
            return $stmt->fetch(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }

        function getPersonRoleId($per_id) {
        try {
            $sql = "SELECT prl_id FROM person_role WHERE prl_ref_person = :per_id";
            $conn = \db_connection::connection();           
            $stmt = $conn->prepare($sql);
            $stmt->execute([':per_id' => $per_id]);
            // print_r($per_id);
            return $stmt->fetch(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }
}
 ?>
