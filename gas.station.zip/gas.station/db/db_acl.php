<?php

include_once "../db/connection.php";

class db_acl{

    public $table="acl";
    public $field_arr = [

        0 =>[
            "field" => "acl_id", 
            "type" => "int",
            "default" => ""
        ],
        1 =>[
            "field" => "acl_role",
            "type" => "string",
            "default" => ""

        ],
        2 =>[
            "field" => "acl_level",
            "type" => "int",
            "default" => ""        
        ],
    ];

    public $value_arr = [];

    function set_default(){
         foreach($this->field_arr as $field)  {
            $this->value_arr[$field["field"]] = $field["default"];
         } 
    }

    public function getAclId($acl_id) {
        try {

            $sql = "SELECT acl_id FROM acl WHERE acl_id = :acl_id";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute([':acl_id' => $acl_id]);
            return $stmt->fetch(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }

    public function getAclRole($acl_id) {
        try {

            $sql = "SELECT acl_role FROM acl WHERE acl_level = :acl_id";
            $conn = \db_connection::connection(); 
            $stmt = $conn->prepare($sql);
            $stmt->execute([':acl_id' => $acl_id]);
            return $stmt->fetch(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }

    public function getAclIdByRole($acl_role) {
        try {

            $conn = \db_connection::connection();

            $sql = "SELECT acl_id FROM acl WHERE acl_role = :acl_role";

            $stmt = $conn->prepare($sql);
            $stmt->execute([':acl_role' => $acl_role]);
            return $stmt->fetch(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }
}
 ?>
