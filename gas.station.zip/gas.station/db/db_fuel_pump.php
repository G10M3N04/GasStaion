<?php

include_once "../db/connection.php";
class db_fuel_pump extends db_base{

    public $table="fuel_pump";
    public $field_arr = [

        0 =>[
            "field" => "flp_id", 
            "type" => "int",
            "default" => ""
        ],
        1 =>[
            "field" => "flp_ref_tank",
            "type" => "int",
            "default" => ""

        ],
        2 =>[
            "field" => "flp_pump_num",
            "type" => "int",
            "default" => ""        
        ],
        3 =>[
            "field" => "flp_fuel_type",
            "type" => "string",
            "default" => ""        
        ],
        4 =>[
            "field" => "flp_price_per_litre",
            "type" => "int",
            "default" => ""        
        ],
        5 =>[
            "field" => "flp_is_active",
            "type" => "int",
            "default" => ""        
        ],
    ];

    public $value_arr = [];

    function set_default(){
         foreach($this->field_arr as $field)  {
            $this->value_arr[$field["field"]] = $field["default"];
         } 
    }
    
    function getPumpByTank(){

    $conn = \db_connection::connection();

    $sql = "SELECT * FROM fuel_pump LEFT JOIN tank ON (tnk_id = flp_ref_tank)";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_OBJ); // return objects
    }

    function getAllFuelPumpObj(){

    $sql = "SELECT * FROM fuel_pump";
    $conn = \db_connection::connection();
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_OBJ);
    }

    function getActivePump(){

    $sql = "SELECT * FROM fuel_pump WHERE flp_is_active = 1";
    $conn = \db_connection::connection();
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_OBJ);
    }

    function getJoinedPumpAndReadings(){

    $conn = \db_connection::connection();

    $sql = "SELECT * FROM fuel_pump LEFT JOIN fuel_readings ON (flp_id = flr_ref_fuel_pump)";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_OBJ); // return objects
    }

    public function getFuelPumpObjByID($flp_id) {
        try {

            $sql = "SELECT * FROM fuel_pump  WHERE flp_id = :flp_id";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute([':flp_id' => $flp_id]);
            return $stmt->fetch(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }

    function getJoinedTanksAndPump(){

    $conn = \db_connection::connection();

    $sql = "SELECT * FROM tank LEFT JOIN fuel_pump ON (tnk_id = flp_ref_tank)";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_OBJ); // return objects
    }
}

?>
