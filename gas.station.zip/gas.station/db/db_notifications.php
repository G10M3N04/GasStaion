<?php
include_once "../db/connection.php";

class db_notification extends db_base{

    public $table="notifications";
    public $field_arr = [

        0 =>[
            "field" => "not_id", 
            "type" => "int",
            "default" => ""
        ],
        1 =>[
            "field" => "not_ref_person",
            "type" => "int",
            "default" => ""
        ],
        2 =>[
            "field" => "not_title",
            "type" => "string",
            "default" => ""
        ],
        3 =>[
            "field" => "not_type",
            "type" => "string",
            "default" => ""        
        ],
        4 =>[
            "field" => "not_message",
            "type" => "string",
            "default" => ""        
        ],
        5 =>[
            "field" => "not_date",
            "type" => "date",
            "default" => ""        
        ],
        6 =>[
            "field" => "not_is_active",
            "type" => "int",
            "default" => ""        
        ],
    ];

    public $value_arr = [];

    function set_default(){
         foreach($this->field_arr as $field)  {
            $this->value_arr[$field["field"]] = $field["default"];
         } 
    }

    public function getAllNotifications() {
        try {

            $sql = "SELECT * FROM notifications WHERE not_is_active = 1";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }

    public function getNotificationObjByID($not_id) {
        try {

            $sql = "SELECT * FROM notifications WHERE not_id = :not_id";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute([':not_id' => $not_id]);
            return $stmt->fetch(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }
}

 ?>
