<?php

include_once "../db/connection.php";
require_once "C:\Projects\gas.station\db\db_base.php";

class db_person extends db_base{

    public $table="person";
    public $field_arr = [

        0 =>[
            "field" => "per_id", 
            "type" => "int",
            "default" => ""
        ],
        1 =>[
            "field" => "per_firstname",
            "type" => "string",
            "default" => ""

        ],
        2 =>[
            "field" => "per_lastname",
            "type" => "string",
            "default" => ""        
        ],
        3 =>[
            "field" => "per_username",
            "type" => "string",
            "default" => ""        
        ],
        4 =>[
            "field" => "per_password",
            "type" => "string",
            "default" => ""        
        ],
        5 =>[
            "field" => "per_email",
            "type" => "string",
            "default" => ""        
        ],
        6 =>[
            "field" => "per_phone",
            "type" => "string",
            "default" => ""        
        ],
        7 =>[
            "field" => "per_idnr",
            "type" => "string",
            "default" => ""        
        ],
        8 =>[
            "field" => "per_dob",
            "type" => "string",
            "default" => ""        
        ],
        9 =>[
            "field" => "per_gender",
            "type" => "char",
            "default" => ""        
        ],
        10 =>[
            "field" => "per_ethnicity",
            "type" => "string",
            "default" => ""        
        ],
        11 =>[
            "field" => "per_date_added",
            "type" => "datetime",
            "default" => ""        
        ],
        12 =>[
            "field" => "per_is_active",
            "type" => "bool",
            "default" => ""        
        ],
    ];

    public $value_arr = [];

    function set_default(){
         foreach($this->field_arr as $field)  {
            $this->value_arr[$field["field"]] = $field["default"];
         } 
    }


    public function usernameExists($username) {
        try {
            $sql = "SELECT COUNT(*) AS count FROM person WHERE per_username = :username";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute([':username' => $username]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['count'] > 0; // true if username exists
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }

    public function emailExists($email) {
        try {
            $sql = "SELECT COUNT(*) AS count FROM person WHERE per_email = :per_email"; // Queries counts the amount of times the user input gets encountered
            $conn = \db_connection::connection(); // Connect to gasstation db
            $stmt = $conn->prepare($sql);
            $stmt->execute([':per_email' => $email]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['count'] > 0; // true if email exists
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }

    public function passwordExists($password) {
        try {

            $sql = "SELECT COUNT(*) AS count FROM person WHERE per_password = :per_password";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute([':per_password' => $password]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['count'] > 0; // true if password exists
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }

    public function getPersonByUsername($username) {
        try {

            $sql = "SELECT per_id FROM person WHERE per_username = :per_username";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute([':per_username' => $username]);
            return $stmt->fetch(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }
        public function getPersonByID($per_id) {
        try {

            $sql = "SELECT per_firstname, per_lastname FROM person WHERE per_id = :per_id";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute([':per_id' => $per_id]);
            return $stmt->fetch(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }

    public function getPersonAllActive() {
        try {

            $sql = "SELECT CONCAT(per_firstname, ' ', per_lastname) as full_name, per_idnr, per_phone, per_email, per_id FROM person WHERE per_is_active = 1";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }
    public function getPersonObjByID($per_id) {
        try {

            $sql = "SELECT * FROM person WHERE per_id = :per_id";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute([':per_id' => $per_id]);
            return $stmt->fetch(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }
}
 ?>
