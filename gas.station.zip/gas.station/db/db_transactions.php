<?php
include_once "../db/connection.php";

class db_transactions{

    public $table="transactions";
    public $field_arr = [

        0 =>[
            "field" => "tns_id", 
            "type" => "int",
            "default" => ""
        ],
        1 =>[
            "field" => "tns_ref_cashup",
            "type" => "int",
            "default" => ""        
        ],
        2 =>[
            "field" => "tns_ref_person",
            "type" => "int",
            "default" => ""        
        ],
        3 =>[
            "field" => "tns_ref_products",
            "type" => "int",
            "default" => ""        
        ],
        2 =>[
            "field" => "tns_ref_fuel_pump",
            "type" => "string",
            "default" => ""

        ],
        3 =>[
            "field" => "tns_description",
            "type" => "string",
            "default" => ""        
        ],
        4 =>[
            "field" => "tns_amount",
            "type" => "currency",
            "default" => ""        
        ],
        5 =>[
            "field" => "tns_date",
            "type" => "date",
            "default" => ""        
        ],
    ];

    public $value_arr = [];

    function set_default(){
         foreach($this->field_arr as $field)  {
            $this->value_arr[$field["field"]] = $field["default"];
         } 
    }

    function loadTransactions() {

    $path = __DIR__ . "/app/data/transactions.json";
    $data = file_get_contents($path);
    $transactions = json_decode($data, true);

    }

    public function getAllTransactions()
    {       
        try {
            $conn = \db_connection::connection();
            $sql = "SELECT * FROM transactions ORDER BY tns_date DESC";
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_OBJ);

        } catch (PDOException $e) {
            echo "DB error: " . $e->getMessage();
            return [];
        }
    }

    public function getTransObjByID($tns_id) {
        try {

            $sql = "SELECT * FROM transactions WHERE tns_id = :tns_id";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute([':tns_id' => $tns_id]);
            return $stmt->fetch(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }

    public function insert(array $data) {
        $sql = "
        INSERT INTO db_transaction
        (trn_date, trn_type, trn_amount, trn_reference)
        VALUES (:date, :type, :amount, :ref)
        ";
        $conn = \db_connection::connection();
        $stmt = $conn->prepare($sql);

        $stmt->execute([
            'date'   => $data['trn_date'],
            'type'   => $data['trn_type'],
            'amount' => (float) $data['trn_amount'],
            'ref'    => $data['trn_reference']
        ]);
    }
}

?>
