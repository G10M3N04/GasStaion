<?php
include_once "../db/connection.php";

class db_reports{

    public $table="reports";
    public $field_arr = [

        0 =>[
            "field" => "rep_id", 
            "type" => "int",
            "default" => ""
        ],
        1 =>[
            "field" => "rep_ref_person",
            "type" => "int",
            "default" => ""

        ],
        2 =>[
            "field" => "rep_type",
            "type" => "string",
            "default" => ""        
        ],
        3 =>[
            "field" => "rep_date",
            "type" => "date",
            "default" => ""        
        ],
        4 =>[
            "field" => "rep_filepath",
            "type" => "string",
            "default" => ""        
        ],
    ];

    public $value_arr = [];

    function set_default(){
         foreach($this->field_arr as $field)  {
            $this->value_arr[$field["field"]] = $field["default"];
         } 
    }
}
 ?>
