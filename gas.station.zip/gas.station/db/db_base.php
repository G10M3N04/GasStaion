<?php
include_once "../db/connection.php";

class db_base{

    public $field_arr = [];
    public $table = "";
    public $value_arr = [];

function insert($data)
    {               
        $column_arr = array_column($data->field_arr, "field"); // Create string with the field column values
        array_shift($column_arr); // Remove first item from string.
        $columns = implode(', ', $column_arr); // Build string without the first element(per_id)
        $value_arr = implode(",",$data->value_arr); // Get the values from value_arr after info inserted
        $array = explode(",", $value_arr);

        $array = array_map(function($value) {// Trim spaces just in case
            $value = trim($value);
            if ($value === "") {
                return "''";
            }
            // Otherwise, wrap the value in quotes too
            return "'" . addslashes($value) . "'";
        }, $array);

        array_shift($array); // Remove the first element from string

        $values = ltrim(implode(", ", $array),",");


        // Example: Insert into a database table

        $sql = "INSERT INTO $this->table ({$columns}) VALUES ({$values})";

        try {
            // Connect using PDO
            $conn = \db_connection::connection();

            // Set error mode to exceptions
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // Example insert query
            
            $stmt = $conn->prepare($sql);
            $stmt->execute();

            // echo "Record inserted successfully!";

        } catch (PDOException $e) {
            echo "Connection or query failed: " . $e->getMessage();
        }

    }
    // -----------------------------
    // UPDATE
    // -----------------------------
    function update($data){
        
        // Extract columns
        $column_arr = array_column($data->field_arr, "field");
        $primary_key = $column_arr[0];
        array_shift($column_arr); // Remove PK from update fields

        // Extract values
        $value_arr = $data->value_arr;

        $primary_key_value = array_shift($value_arr); // Remove PK value

        // Build SET clause
        $set_parts = [];
 
        foreach ($column_arr as $col) {
            if (array_key_exists($col, $value_arr)) {
                $set_parts[] = "$col = '$value_arr[$col]'";
            }
        }

        $set_clause = implode(", ", $set_parts);
        
        $sql = "UPDATE $this->table SET $set_clause WHERE $primary_key = $primary_key_value";

                
        try {
            $conn = \db_connection::connection();
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $stmt = $conn->prepare($sql);
            // Bind all update values + final PK value

            $stmt->execute();

            // echo "Record updated successfully!";
        } catch (PDOException $e) {
            echo "Update failed: " . $e->getMessage();
        }
    }

    // -----------------------------
    // DELETE
    // -----------------------------
   function delete($data){

        // Extract columns
        $column_arr = array_column($data->field_arr, "field");
        $primary_key = $column_arr[0];
        array_shift($column_arr); // Remove PK from update fields

        // Extract values
        $value_arr = $data->value_arr;

        $primary_key_value = array_shift($value_arr); // Remove PK value

        // Build SET clause
        $set_parts = [];
 
        foreach ($column_arr as $col) {
            if (array_key_exists($col, $value_arr)) {
                // $set_parts[] = "$col = '$value_arr[$col]'";
                if (strpos($col, "is_active") !== false) {
                // Example: handle is_active as integer (no quotes)
                $set_parts[] = "$col = " . intval($value_arr[$col]);
                continue; 
                }
               
            }

        }

        $set_clause = implode(", ", $set_parts);
        
        $sql = "UPDATE $this->table SET $set_clause WHERE $primary_key = $primary_key_value";

        print_r("UPDATE $this->table SET $set_clause WHERE $primary_key = $primary_key_value");


                
        try {
            $conn = \db_connection::connection();
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $stmt = $conn->prepare($sql);

            $stmt->execute();

            // echo "Record updated successfully!";
        } catch (PDOException $e) {
            echo "Update failed: " . $e->getMessage();
        }
    }
}    