<?php
    class db_connection {

        private static $conn = false;

        public static function connection(){

        if (self::$conn) return self::$conn;

        $serverName = "localhost";
        $database = "gasstation";
        $username = "gio";
        $password = "giovanni1";


        try {
            // Connect using PDO
            $conn = new PDO("sqlsrv:Server=$serverName;Database=$database", $username, $password);

            // Set error mode to exceptions
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            self::$conn = $conn;
            return $conn;

        } catch (PDOException $e) {
            echo "Connection or query failed: " . $e->getMessage();
        }
    }

    }

?>
