<?php
include_once "../db/connection.php";

class db_tank extends db_base{

    public $table="tank";
    public $field_arr = [

        0 =>[
            "field" => "tnk_id", 
            "type" => "int",
            "default" => ""
        ],
        1 =>[
            "field" => "tnk_ref_person",
            "type" => "int",
            "default" => ""        
        ],
        2 =>[
            "field" => "tnk_ref_manager",
            "type" => "int",
            "default" => ""

        ],
        3 =>[
            "field" => "tnk_fuel_volume",
            "type" => "decimal",
            "default" => ""        
        ],
        4 =>[
            "field" => "tnk_type",
            "type" => "string",
            "default" => ""        
        ],
        5 =>[
            "field" => "tnk_is_active",
            "type" => "int",
            "default" => ""        
        ],
    ];

    public $value_arr = [];

    function set_default(){
         foreach($this->field_arr as $field)  {
            $this->value_arr[$field["field"]] = $field["default"];
         } 
    }
    
    function getTankById($tnk_id){

        $conn = \db_connection::connection();

        $sql = "SELECT * FROM tank WHERE tnk_id = :tnk_id";
        $stmt = $conn->prepare($sql);
        $stmt->execute(['tnk_id' => $tnk_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC); // return objects
    }

    function getStatus($percentage)
    {
        if ($percentage <= 5)  return "EMPTY";
        if ($percentage <= 20) return "LOW";
        if ($percentage == 50) return "GOOD";
        if ($percentage >= 90) return "PERFECT";

        return "OK";
    }

    function getAllTankObj(){

    $sql = "SELECT * FROM tank WHERE tnk_is_active = 1";
    $conn = \db_connection::connection();
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_OBJ);
    }

    public function getTankObjByID($tnk_id) {
        try {

            $sql = "SELECT * FROM tank WHERE tnk_id = :tnk_id";
            $conn = \db_connection::connection();
            $stmt = $conn->prepare($sql);
            $stmt->execute([':tnk_id' => $tnk_id]);
            return $stmt->fetch(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            echo "Validation error: " . $e->getMessage();
            return false;
        }
    }

    function getJoinedTanksAndPump(){

    $conn = \db_connection::connection();

    $sql = "SELECT * FROM tank LEFT JOIN fuel_pump ON (tnk_id = flp_ref_tank)";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_OBJ); // return objects
    }

}
 ?>
